package ti.dam.geoloc_memoire.Adapters;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;


/**
 * Created by khalilrockmetal on 27/02/17.
 */



public class CustomDemandeAdapter extends BaseAdapter{

    Context context;
    List<User> demandes;

    ImageView photo;

//    static String accepter_url = "http://169.254.30.200:2145/Projects/Android/app/accepter_demande.php";
//    static String refuser_url = "http://169.254.30.200:2145/Projects/Android/app/refuser_demande.php";

    static String accepter_url = "http://android-php.000webhostapp.com/android/accepter_demande.php";
    static String refuser_url = "http://android-php.000webhostapp.com/android/refuser_demande.php";


    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

    static boolean accepter ;


    public CustomDemandeAdapter(Context context , ArrayList<User> demandes){
        this.context=context;
        this.demandes=demandes;
    }

    @Override
    public int getCount() {
        return demandes.size();
    }

    @Override
    public Object getItem(int position){
        return demandes.get(position);
    }

    @Override
    public long getItemId(int position) {
        return demandes.indexOf(getItem(position));
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View getView(final int position, View view, final ViewGroup viewGroup) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null){
            view = layoutInflater.inflate(R.layout.custom_demande_view , null);
        }

        photo = (ImageView) view.findViewById(R.id.demande_photo);
        final TextView name = (TextView) view.findViewById(R.id.demande_name);
        Button accept = (Button) view.findViewById(R.id.accept);
        Button deny = (Button) view.findViewById(R.id.deny);



        if (position < demandes.size()) {
            if (!demandes.get(position).img.equals("")) {
//                String url = "http://169.254.30.200:2145/Projects/Android/app/" + demandes.get(position).img;
            String url = "http://android-php.000webhostapp.com/android/"+demandes.get(position).img;
                Picasso.with(context).load(url).into(photo);
            } else
                photo.setBackground(context.getResources().getDrawable(R.drawable.user));

        }


        final View finalView = view;

        if (position < demandes.size())
        name.setText(demandes.get(position).firstname + " " + demandes.get(position).lastname);



        final Animation remove = AnimationUtils.loadAnimation(context , R.anim.remove_anim);
        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Session session = new Session(context);
                String id_account = session.getID();
                String id_ami = null;
                id_ami = demandes.get(position).id;

                accepterDemandeRequest(context, accepter_url, id_account, id_ami);
                demandes.remove(demandes.get(position));


                getView(position, finalView, viewGroup);


//                if (demandes.size() > 0) {
//                    id_ami = demandes.get(position).id;
//
//                    if (accepterDemandeRequest(context, accepter_url, id_account, id_ami)) {
//                        demandes.remove(demandes.get(position));
//                        getView(position, finalView, viewGroup);
//
//                    }
//                }

            }
        });

        deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                    Session session = new Session(context);
                    String id_account = session.getID();
                    String id_ami = null;
                    id_ami = demandes.get(position).id;


                refuseDemande(context, refuser_url, id_account, id_ami);
                demandes.remove(demandes.get(position));

                getView(position, finalView, viewGroup);


            }
        });


        notifyDataSetChanged();
        return view;
    }



    public void clear(){
        demandes.clear();
    }


    ///////////////////////////////////////HTTP REQUEST ACCEPTER DEMANDE ///////////////////////////////

    public boolean accepterDemandeRequest(final Context context , String url , final String id_account , final String id_ami ){


        requestQueue = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {



                        if (response.contains("success")){
                            Toast.makeText(context  ,"demande accepter" ,Toast.LENGTH_SHORT).show();
                            accepter = true;
                        }else{
                            Toast.makeText(context  ,"demande nom accepter" ,Toast.LENGTH_SHORT).show();
                            accepter = false;
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context  ,"Error connection" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("idaccount", id_account);
                params.put("idami", id_ami);

                return params;
            }
        };

        requestQueue.add(stringRequest);

        return accepter;
    }
    ///////////////////////////////SUPP DEMANDE ////////////////////////////////////////

    public void refuseDemande(final Context context ,String url , final String id_account ,final String id_ami){


        requestQueue2 = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {



                        if (response.contains("success")){
                            Toast.makeText(context  ,"demande refuser" ,Toast.LENGTH_SHORT).show();

                        }else{
                            Toast.makeText(context  ,"demande nom refuser" ,Toast.LENGTH_SHORT).show();

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context  ,"Error connection" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("idaccount", id_account);
                params.put("idami", id_ami);

                return params;
            }
        };

        requestQueue2.add(stringRequest);
    }
}
