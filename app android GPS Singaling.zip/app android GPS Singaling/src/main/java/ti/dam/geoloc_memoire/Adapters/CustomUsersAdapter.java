package ti.dam.geoloc_memoire.Adapters;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;


/**
 * Created by khalilrockmetal on 20/03/17.
 */

public class CustomUsersAdapter extends BaseAdapter implements Filterable{

    private Context context;
    private ArrayList<User> users;
    private ArrayList<User> filter_list;

    private Button ajouter;
     TextView name,id_rec;

    CustomFilter filter;

    static boolean  ok ;

    com.android.volley.RequestQueue requestQueue,requestQueue2;



//    static String url = "http://169.254.30.200:2145/Projects/Android/app/envoyer_demande.php";

    static String url = "http://android-php.000webhostapp.com/android/envoyer_demande.php";
    static String url_s = "http://android-php.000webhostapp.com/android/delete_demande.php";




    public CustomUsersAdapter(Context context , ArrayList<User> users){
        this.context=context;
        this.users=users;
        this.filter_list = users;
    }

    @Override
    public int getCount() {
        return users.size();
    }

    @Override
    public Object getItem(int position) {
        return users.get(position);
    }

    @Override
    public long getItemId(int position) {
        return users.indexOf(getItem(position));
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View getView(final int position, View view, final ViewGroup viewGroup) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null){
            view = layoutInflater.inflate(R.layout.custom_user_view , null);
        }

        ImageView photo = (ImageView) view.findViewById(R.id.user_photo);

        name = (TextView) view.findViewById(R.id.user_name);

        ajouter = (Button) view.findViewById(R.id.ajouter_amis);


        if(users.get(position).etat.equals("demande")){
            ajouter.setText(view.getResources().getString(R.string.delete));
        }

        name.setText(users.get(position).firstname+" "+users.get(position).lastname);


            if (!users.get(position).img.equals("")) {
//                String url = "http://169.254.30.200:2145/Projects/Android/app/" + users.get(position).img;
                String url = "http://android-php.000webhostapp.com/android/"+users.get(position).img;

                Picasso.with(context).load(url).into(photo);
            } else
                photo.setBackground(context.getResources().getDrawable(R.drawable.user));

        final String id_recep = users.get(position).getId();


        final View finalView = view;
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (position < users.size()) {
                    String id_recep = users.get(position).id;
                    Session session = new Session(context);
                    String id_emet = session.getID();

                    if (users.get(position).etat.equals("demande")) {
                        suppDemande(context, url_s, id_emet, id_recep, v);
                    } else {
                        envoyerDemande(context, url, id_emet, id_recep, v);
                    }
                }



                Log.i("tag" , "id + "+users.get(position).id);

                //users.remove(position);
                //Toast.makeText(view.getContext() , id_recep , Toast.LENGTH_SHORT).show();
            }
        });


        return view;
    }

    private void suppDemande(final Context context, final  String url, final String id_emet, final String id_recep, final View view) {
        requestQueue2 = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Toast.makeText(context  ,"demande supprimer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("failed")){
                            Toast.makeText(context  ,"demande non supprimer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("nonexist")){
                            Toast.makeText(context  ,"demande deja supprimer" ,Toast.LENGTH_SHORT).show();
                            Button add = (Button) view.findViewById(R.id.ajouter_amis);
                            add.setBackground(view.getResources().getDrawable(R.drawable.custom_button_deny));
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context  ,"Error connection" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("idemet", id_emet);
                params.put("idrecep", id_recep);

                return params;
            }
        };
        requestQueue2.add(stringRequest);
    }

    public void envoyerDemande(final Context context ,String url , final String id_emet , final String id_recep,final  View view ){

        requestQueue = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Toast.makeText(context  ,"demande envoyer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("failed")){
                            Toast.makeText(context  ,"demande non envoyer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("exist")){
                            Toast.makeText(context  ,"demande deja envoyer" ,Toast.LENGTH_SHORT).show();
                            Button add = (Button) view.findViewById(R.id.ajouter_amis);
                            add.setBackground(view.getResources().getDrawable(R.drawable.custom_button_deny));
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context  ,"Error connection" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id_emet", id_emet);
                params.put("id_recep", id_recep);

                return params;
            }
        };
        requestQueue.add(stringRequest);
    }


    @Override
    public android.widget.Filter getFilter(){

        if (filter == null){
            filter = new CustomFilter();
        }

        return filter;
    }
    class CustomFilter extends android.widget.Filter {


        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {

            FilterResults filterResults = new FilterResults();

            if (charSequence != null && charSequence.length() > 0){

                charSequence.toString().toUpperCase();

                ArrayList<User> filters = new ArrayList<>();

                for (int i=0 ; i<filter_list.size() ; i++){

                    if(filter_list.get(i).firstname.toLowerCase().contains(charSequence)) {

                        User ami = new User(filter_list.get(i).id ,filter_list.get(i).firstname , filter_list.get(i).lastname , filter_list.get(i).img ,filter_list.get(i).etat);
                        filters.add(ami);
                    }
                }

                filterResults.count = filters.size();
                filterResults.values = filters;
            }else {

                filterResults.count = filter_list.size();
                filterResults.values = filter_list;

            }

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            users = (ArrayList<User>) filterResults.values;
            notifyDataSetChanged();

        }
    }

    public void clear(){

        if (users.size() > 0){
        users.clear();
        notifyDataSetChanged();}
    }



}
