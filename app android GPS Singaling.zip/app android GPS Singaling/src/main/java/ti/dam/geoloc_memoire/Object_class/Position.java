package ti.dam.geoloc_memoire.Object_class;

/**
 * Created by khalilrockmetal on 04/05/17.
 */

public class Position {
    public String date ;
    public String address ;

    public Position(String date, String address) {
        this.date = date;
        this.address = address;
    }
}
