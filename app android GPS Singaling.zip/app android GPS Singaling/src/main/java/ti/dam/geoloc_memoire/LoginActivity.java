package ti.dam.geoloc_memoire;



import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;


/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    TextView register ;
    EditText email , passwd ;
    Button login;
    View layout_login;

    ProgressDialog loading ;


    static String em;
    static String ps;

    com.android.volley.RequestQueue requestQueue;

    static String login_url = "http://android-php.000webhostapp.com/android/login.php";
//    static String login_url = "http://169.254.30.200:2145/Projects/Android/app/login.php";

    ProgressDialog progressDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_login);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        email = (EditText) findViewById(R.id.email);
        passwd = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login_button);
        register = (TextView) findViewById(R.id.register);
        layout_login = findViewById(R.id.login_rl);

        Animation fadein = new AlphaAnimation(0,1) ;
        fadein.setInterpolator(new DecelerateInterpolator());
        fadein.setDuration(5000);

        AnimationSet animationSet = new AnimationSet(false);
        animationSet.addAnimation(fadein);

        layout_login.setAnimation(animationSet);

        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivityForResult(intent , 1);
            }
        });


        final Animation alpha = AnimationUtils.loadAnimation(getApplication() , R.anim.alpha_anim);
        login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                view.startAnimation(alpha);



                requestQueue = Volley.newRequestQueue(LoginActivity.this);

                 em  = email.getText().toString();
                 ps  = passwd.getText().toString();

                progressDialog = new ProgressDialog(LoginActivity.this);
                progressDialog.setMessage("Plzz Wait...");
                progressDialog.setIndeterminate(false);
                progressDialog.setCancelable(true);
                progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);


                if (!isEmpty(em , ps)) {

                    progressDialog.show();

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, login_url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    progressDialog.dismiss();

                                    if (response.contains("success")) {
                                        //Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();

                                        Session session = new Session(getApplication());
                                        session.setEmail(em);
                                        session.setPasswd(ps);

                                        Intent i = new Intent(LoginActivity.this , MainActivity.class);
                                        startActivity(i);
                                    }

                                    if (response.contains("failed")) {
                                        //Toast.makeText(getApplicationContext(), "email or password incorrect", Toast.LENGTH_SHORT).show();
                                        email.setError(getResources().getString(R.string.invalid_email));
                                        passwd.setError(getResources().getString(R.string.invalid_psw));

                                    }

                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_connection), Toast.LENGTH_SHORT).show();
                            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                            progressDialog.dismiss();

                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<>();
                            params.put("login_email" , em);
                            params.put("login_passwd" , ps);
                            return params;
                        }
                    };
                    requestQueue.add(stringRequest);

                }

            } ///// END LOGIN.ONCLICK
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1){
            if (resultCode == RESULT_OK){
                email = (EditText) findViewById(R.id.email);
                passwd = (EditText) findViewById(R.id.password);

                String e = data.getStringExtra("email");
                String p = data.getStringExtra("passwd");

                email.setText(e);
                passwd.setText(p);


            }
        }

    }
    @Override
    protected void onResume() {
        super.onResume();
        Session session = new Session(getApplicationContext());
        String x = session.getEmail();
        if (x == ""){
        email = (EditText) findViewById(R.id.email);
        passwd = (EditText) findViewById(R.id.password);
        email.setText("");
        passwd.setText("");}

    }

    ///////////////////check if email & pasword are not empty ///////////
    public boolean isEmpty(String em , String ps){

        boolean b = false ;

        if ( em.length() == 0 || em.contains(" ")){
            email.setError(getResources().getString(R.string.email_required));
            b = true;
        }
        if ( ps.length() == 0 || ps.contains(" ")){
            passwd.setError(getResources().getString(R.string.psw_required));
            b = true;
        }

        return b;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        Intent intent = new Intent();
        intent.putExtra("finish" , "finish");
        setResult(0 , intent);
    }
}



