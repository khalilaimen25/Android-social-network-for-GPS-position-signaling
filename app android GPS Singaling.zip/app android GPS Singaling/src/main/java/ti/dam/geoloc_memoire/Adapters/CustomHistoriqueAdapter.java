package ti.dam.geoloc_memoire.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ti.dam.geoloc_memoire.Object_class.Position;
import ti.dam.geoloc_memoire.R;

/**
 * Created by khalilrockmetal on 04/05/17.
 */

public class CustomHistoriqueAdapter extends BaseAdapter {

    Context context ;
    ArrayList<Position> historique ;

    public CustomHistoriqueAdapter(Context context, ArrayList<Position> historique) {
        this.context = context;
        this.historique = historique;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null) {
            view = layoutInflater.inflate(R.layout.custom_historic_item, null);
        }

        TextView date = (TextView) view.findViewById(R.id.hist_date);
        TextView adr = (TextView) view.findViewById(R.id.hist_adr);

        date.setText(historique.get(position).date);
        adr.setText(" "+historique.get(position).address);

        return view;
    }

    @Override
    public int getCount() {
        return historique.size();
    }

    @Override
    public Object getItem(int i) {
        return historique.get(i);
    }

    @Override
    public long getItemId(int i) {
        return historique.indexOf(getItem(i));
    }



}
