package ti.dam.geoloc_memoire.Tabs;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.AdapterView;
import android.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Adapters.CustomFriendAdapter;
import ti.dam.geoloc_memoire.AddFriendActivity;
import ti.dam.geoloc_memoire.MapsActivity;
import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;
import ti.dam.geoloc_memoire.profileFriendActivity;

import static android.app.Activity.RESULT_OK;

/**
 * Created by khalilrockmetal on 03/03/17.
 */

public class FriendsTab extends Fragment  {

    //FloatingActionButton fab ;
    com.github.clans.fab.FloatingActionButton fab_add_friend;
    com.github.clans.fab.FloatingActionButton map_all_friends;

    ListView list_amis;
    ArrayList<User> amis;
    CustomFriendAdapter customFriendAdapter;
    com.android.volley.RequestQueue requestQueue;
    SearchView searchView;




//    static String url = "http://169.254.30.200:2145/Projects/Android/app/amis.php";

   static String url = "http://android-php.000webhostapp.com/android/amis.php";


    ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab_amis, container, false);


        //fab = (FloatingActionButton) rootView.findViewById(R.id.add_friend);
        fab_add_friend = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.add_friend);
        map_all_friends = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.map_all_friend);

        amis = new ArrayList<>();

        list_amis = (ListView) rootView.findViewById(R.id.list_amis);
        list_amis.setDivider(this.getResources().getDrawable(R.drawable.transperent_color));
        list_amis.setDividerHeight(3);
        searchView = (SearchView) rootView.findViewById(R.id.search_amis);


        customFriendAdapter = new CustomFriendAdapter(getContext() , amis);
        customFriendAdapter.clear();
        customFriendAdapter.notifyDataSetChanged();

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getContext());


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray users = response.getJSONArray("amis");
                            for (int i=0 ; i < users.length() ; i++){

                                JSONObject user = users.getJSONObject(i);

                                String id = user.getString("id_account");
                                String firstname = user.getString("firstname");
                                String lastname = user.getString("lastname");
                                String etat_conex = user.getString("etat");
                                String pos = user.getString("position");
                                String x = user.getString("pos_x");
                                String y = user.getString("pos_y");
                                String img = user.getString("image_path");

                                User new_demande = new User(id , firstname , lastname , img , pos , x , y ,  etat_conex);
                                amis.add(new_demande);

                            }

                            list_amis.setAdapter(customFriendAdapter);
                            customFriendAdapter.notifyDataSetChanged();

                            progressDialog.dismiss();

                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext() , "Error" , Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                Session session = new Session(getContext());
                String id_account = session.getID();
                params.put("idaccount" , id_account);
                //params.put("id_account" , id_account);
                return params;

            }
        };


        requestQueue.add(jsonObjectRequest);


        list_amis.setAdapter(customFriendAdapter);


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange( String s) {
                customFriendAdapter.getFilter().filter(s);
                return false;
            }
        });


        fab_add_friend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext() , AddFriendActivity.class);
                startActivity(i);
            }
        });

        map_all_friends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext() , MapsActivity.class);
                i.putParcelableArrayListExtra("amis" , amis);
                startActivity(i);
            }
        });

        list_amis.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String id = amis.get(i).id;
                String position = String.valueOf(i);
                Intent intent = new Intent(getContext() , profileFriendActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("id_account" , id);
                bundle.putString("position" , position );
                intent.putExtras(bundle);
                Log.i("tag" , "position 1 === : "+i);
                startActivityForResult(intent , 66);


            }
        });

        return rootView;

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 66){
            if (resultCode == RESULT_OK){
                String i = data.getStringExtra("position");
                int p = Integer.parseInt(i);
                Log.i("tag" , "position 2=== : "+i);
                Log.i("tag" , "size : "+amis.size());
                amis.remove(p);
                Log.i("tag" , "size : "+amis.size());
                customFriendAdapter.notifyDataSetChanged();

            }
        }

    }

    private boolean _hasLoadedOnce= false; // your boolean field

    @Override
    public void setUserVisibleHint(boolean isFragmentVisible_) {
        super.setUserVisibleHint(true);


        if (this.isVisible()) {
            // we check that the fragment is becoming visible
            if (isFragmentVisible_ ) {
                //Toast.makeText(getContext() , "fragment selected" , Toast.LENGTH_SHORT).show();

                amis = new ArrayList<>();

                list_amis = (ListView) getActivity().findViewById(R.id.list_amis);



                customFriendAdapter = new CustomFriendAdapter(getContext() , amis);
                customFriendAdapter.clear();
                customFriendAdapter.notifyDataSetChanged();

                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Plzz Wait...");
                progressDialog.setIndeterminate(false);
                progressDialog.setCancelable(false);
                progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.show();

                requestQueue = Volley.newRequestQueue(getContext());


                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {

                                try {
                                    JSONArray users = response.getJSONArray("amis");
                                    for (int i=0 ; i < users.length() ; i++){

                                        JSONObject user = users.getJSONObject(i);

                                        String id = user.getString("id_account");
                                        String firstname = user.getString("firstname");
                                        String lastname = user.getString("lastname");
                                        String etat_conex = user.getString("etat");
                                        String pos = user.getString("position");
                                        String img = user.getString("image_path");
                                        String x = user.getString("pos_x");
                                        String y = user.getString("pos_y");

                                        User new_demande = new User(id , firstname , lastname, img , pos,x,y ,etat_conex );
                                        amis.add(new_demande);

                                    }

                                    list_amis.setAdapter(customFriendAdapter);
                                    customFriendAdapter.notifyDataSetChanged();

                                }catch (JSONException e){
                                    e.printStackTrace();
                                }

                                progressDialog.dismiss();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getContext() , "Error connection" , Toast.LENGTH_SHORT).show();
                        Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                        progressDialog.dismiss();
                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();

                        Session session = new Session(getContext());
                        String id_account = session.getID();
                        params.put("idaccount" , id_account);
                        //params.put("id_account" , id_account);
                        return params;

                    }
                };

                jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                        5000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                requestQueue.add(jsonObjectRequest);

            }
        }
    }


}
