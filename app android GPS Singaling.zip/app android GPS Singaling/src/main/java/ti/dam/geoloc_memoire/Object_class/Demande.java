package ti.dam.geoloc_memoire.Object_class;

/**
 * Created by khalilrockmetal on 27/02/17.
 */

public class Demande {

    public int image_id;
    public String name ;
    //int accept_id;
    //int deny_id;

    public Demande(int image_id , String name){
        this.image_id = image_id;
        this.name = name;
            }

}
