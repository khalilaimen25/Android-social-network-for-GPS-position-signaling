package ti.dam.geoloc_memoire;

import android.app.ProgressDialog;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Adapters.CustomHistoriqueAdapter;
import ti.dam.geoloc_memoire.Object_class.Position;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;

public class HistoricActivity extends AppCompatActivity {

    ListView list_hist;
    ArrayList<Position> postions;
    CustomHistoriqueAdapter customHistoriqueAdapter;
    com.android.volley.RequestQueue requestQueue;
    ProgressDialog progressDialog ;

    static String hist_url = "http://android-php.000webhostapp.com/android/getPositions.php";


    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historic);
        setupActionBar();

        postions = new ArrayList<>();
        list_hist = (ListView) findViewById(R.id.list_hist);
        customHistoriqueAdapter = new CustomHistoriqueAdapter(getApplication() , postions );

        getHist(hist_url);
    }

    public void getHist(String url){

        progressDialog = new ProgressDialog(HistoricActivity.this);
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {



                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray users = response.getJSONArray("positions");
                            for (int i=0 ; i < users.length() ; i++){
                                JSONObject pos = users.getJSONObject(i);

                                String date = pos.getString("date");
                                String address = pos.getString("address");

                                Position new_pos = new Position(date , address);
                                postions.add(new_pos);

                            }

                           // Toast.makeText(getApplicationContext(),""+postions.size(),Toast.LENGTH_LONG).show();


                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        list_hist.setAdapter(customHistoriqueAdapter);

                        progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


               // Toast.makeText(getApplicationContext() , "Error" , Toast.LENGTH_SHORT).show();
                Log.i("tag" , "==============================="+error);
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                Session session = new Session(getApplicationContext());
                params.put("idaccount" , session.getID());
                //params.put("id_account" , id_account);
                return params;

            }
        };

        requestQueue.add(jsonObjectRequest);
    }
}
