package ti.dam.geoloc_memoire.Adapters;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


import ti.dam.geoloc_memoire.MapsActivity;
import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.User;

/**
 * Created by khalilrockmetal on 15/03/17.
 */

public class CustomFriendAdapter extends BaseAdapter implements Filterable{

    Context context;
    ArrayList<User> friends;
    ArrayList<User> filter_list;
    CustomFilter filter;

    Button map;

    public CustomFriendAdapter(Context context , ArrayList<User> friends){
        this.context=context;
        this.friends=friends;
        this.filter_list = friends;
    }

    @Override
    public int getCount() {
        return friends.size();
    }

    @Override
    public Object getItem(int position){
        return friends.get(position);
    }

    @Override
    public long getItemId(int position) {
        return friends.indexOf(getItem(position));
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null){
            view = layoutInflater.inflate(R.layout.custom_friend_view , null);
        }

        ImageView photo = (ImageView) view.findViewById(R.id.friend_photo);
        ImageView etat_c = (ImageView) view.findViewById(R.id.friend_etat_conex);
        final TextView name = (TextView) view.findViewById(R.id.friend_name);
        TextView location = (TextView) view.findViewById(R.id.friend_position);
        map = (Button) view.findViewById(R.id.map_btn);

        //photo.setImageResource(friends.get(position).image_id);
        name.setText(friends.get(position).firstname+" "+friends.get(position).lastname);


            if (friends.get(position).etat.equals("c")) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    etat_c.setBackground(context.getResources().getDrawable(R.drawable.online));
                }
            }

            if (!friends.get(position).position.equals("null"))
                location.setText(friends.get(position).position);
            else
                location.setText(context.getResources().getString(R.string.map_not_available));

        if (friends.size() > 0) {
            if (!friends.get(position).img.equals("")) {
//                String url = "http://169.254.30.200:2145/Projects/Android/app/" + friends.get(position).img;
                String url = "http://android-php.000webhostapp.com/android/" + friends.get(position).img;
                photo.setMaxWidth(80);
                photo.setMaxHeight(60);
                Picasso.with(context).load(url).into(photo);
            } else
                photo.setBackground(context.getResources().getDrawable(R.drawable.user));

        }

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            if (friends.get(position).x.equals("null"))
            {
                Toast.makeText(context,"map "+context.getResources().getText(R.string.map_not_available), Toast.LENGTH_SHORT).show();
            }else {
                Intent intent = new Intent(context, MapsActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("x", friends.get(position).x);
                bundle.putString("y", friends.get(position).y);
                bundle.putString("pos", friends.get(position).position);
                bundle.putString("name", friends.get(position).firstname+" "+friends.get(position).lastname);
                intent.putExtras(bundle);
                context.startActivity(intent);

//                Dialog dialog = new Dialog(context);
//                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//                dialog.setContentView(R.layout.custom_dialogmap);
//                dialog.show();
//                GoogleMap googleMap;
//
//
//                MapView mMapView = (MapView) dialog.findViewById(R.id.mapView);
//                MapsInitializer.initialize(context);
//
//                mMapView = (MapView) dialog.findViewById(R.id.mapView);
//                mMapView.onCreate(dialog.onSaveInstanceState());
//                mMapView.onResume();// needed to get the map to display immediately
//                googleMap = mMapView.getMap();
            }
            }
        });


        return view;
    }

    @Override
    public android.widget.Filter getFilter(){

        if (filter == null){
            filter = new CustomFilter();
        }

        return filter;
    }
    class CustomFilter extends android.widget.Filter {


        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {

            FilterResults filterResults = new FilterResults();

            if (charSequence != null && charSequence.length() > 0){

                charSequence.toString();

                ArrayList<User> filters = new ArrayList<>();

                for (int i=0 ; i<filter_list.size() ; i++){

                    if(filter_list.get(i).firstname.toLowerCase().contains(charSequence) || filter_list.get(i).lastname.toLowerCase().contains(charSequence)) {

                        User ami = new User(filter_list.get(i).id ,filter_list.get(i).firstname , filter_list.get(i).lastname ,filter_list.get(i).position , filter_list.get(i).etat , filter_list.get(i).img);
                        filters.add(ami);
                    }
                }

                filterResults.count = filters.size();
                filterResults.values = filters;
            }else {

                filterResults.count = filter_list.size();
                filterResults.values = filter_list;

            }

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {

            friends = (ArrayList<User>) filterResults.values;
            notifyDataSetChanged();

        }
    }

    public void clear(){
        friends.clear();
    }

}
