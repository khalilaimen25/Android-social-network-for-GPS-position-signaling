package ti.dam.geoloc_memoire;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by khalilrockmetal on 21/03/17.
 */

public class HttpRequest {


    com.android.volley.RequestQueue requestQueue;

    public void makeRequest(final Context context , String url , final String id_emet , final String id_recep , final View view){

        requestQueue = Volley.newRequestQueue(context);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Toast.makeText(context  ,"demande envoyer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("failed")){
                            Toast.makeText(context  ,"demande non envoyer" ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("exist")){
                            Toast.makeText(context  ,"demande deja envoyer" ,Toast.LENGTH_SHORT).show();
                            Button add = (Button) view.findViewById(R.id.ajouter_amis);
                            add.setBackgroundColor(view.getResources().getColor(R.color.added));
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context  ,"ERORR" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id_emet", id_emet);
                params.put("id_recep", id_recep);

                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}
