package ti.dam.geoloc_memoire;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.audiofx.BassBoost;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static com.android.volley.VolleyLog.TAG;

/**
 * Created by khalilrockmetal on 02/04/17.
 */

@SuppressWarnings("MissingPermission")
public class GPS_Service extends Service{

    private LocationListener locationListener;
    private LocationManager locationManager;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Intent intent=new Intent("location_update");
//                intent.putExtra("cord",location.getLongitude()+" "+location.getLatitude());
//                sendBroadcast(intent);
                Log.i(TAG , "location ==========="+location.getLongitude()+" "+location.getLatitude());

                Geocoder geoCoder = new Geocoder(getApplicationContext(), Locale.getDefault());
                StringBuilder builder = new StringBuilder();
                try {
                    List<Address> address = geoCoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if (address.size()>0) {
                        //int maxLines = address.get(0).getMaxAddressLineIndex();
                        for (int i = 0; i < 1; i++) {
//                            String addressStr = address.get(0).getAddressLine(i);
                            String country = address.get(0).getCountryName();
                            String locality = address.get(0).getLocality();
                            builder.append(locality+" "+country);
                            builder.append(" ");
                        }
                    }
                    String finalAddress = builder.toString(); //This is the complete address.

                    Toast.makeText(getApplicationContext(),""+finalAddress,Toast.LENGTH_SHORT).show();

                    intent.putExtra("cord",finalAddress);
                    intent.putExtra("lon",location.getLongitude());
                    intent.putExtra("lat",location.getLatitude());
                    sendBroadcast(intent);

                } catch (IOException e) {
                    // Handle IOException
                } catch (NullPointerException e) {
                    // Handle NullPointerException
                }

            }


            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                Log.i(TAG , "location =========== disableeed");


            }
        };

        locationManager = (LocationManager) getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        //noinspection MissingPermission
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,100000,5,locationListener);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,100000,5,locationListener);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (locationManager!=null){
            locationManager.removeUpdates(locationListener);
        }
    }
}
