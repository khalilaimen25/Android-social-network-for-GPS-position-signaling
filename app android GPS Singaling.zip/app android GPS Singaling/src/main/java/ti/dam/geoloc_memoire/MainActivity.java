package ti.dam.geoloc_memoire;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.widget.Toast;

import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Tabs.DemandeTab;
import ti.dam.geoloc_memoire.Tabs.FriendsTab;
import ti.dam.geoloc_memoire.Tabs.JournalTab;
import ti.dam.geoloc_memoire.Tabs.ProfileTab;

public class MainActivity extends AppCompatActivity {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    public static String email;
    public static String passwd ;

    static String new_account_url = "http://169.254.30.200:2145/Projects/Android/app/nmbr_demande.php";


    com.android.volley.RequestQueue requestQueue;


    BroadcastReceiver broadcastReceiver;



    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.journalt);
        tabLayout.getTabAt(1).setIcon(R.drawable.profilet);
        tabLayout.getTabAt(2).setIcon(R.drawable.friends2);
        tabLayout.getTabAt(3).setIcon(R.drawable.friendst);

//        requestQueue = Volley.newRequestQueue(getApplication());
//
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, new_account_url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        textView.setText(""+response);
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
//                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
//
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                Session session = new Session(getApplicationContext());
//                String id = session.getID();
//                params.put("id_account" , id);
//                return params;
//            }
//        };
//        requestQueue.add(stringRequest);



//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.






    }





    /**
     * A placeholder fragment containing a simple view.
     */


    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {


            switch (position){

                case 0:
                    JournalTab tab1 = new JournalTab();
                    return  tab1;
                case 1:
                    ProfileTab tab2 = new ProfileTab();
                    return  tab2;
                case 2:
                    DemandeTab tab3 = new DemandeTab();
                    return tab3;
                case 3:
                    FriendsTab tab4 = new FriendsTab();
                    return  tab4;
                default:
                    return null;
            }

        }

        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return getResources().getString(R.string.journal);
                case 1:
                    return getResources().getString(R.string.profile);
                case 2:
                    return getResources().getString(R.string.requests);
                case 3:
                    return getResources().getString(R.string.friends);
            }
            return null;
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        //Toast.makeText(getApplicationContext() , "onResume Main" , Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Session session = new Session(getApplication());
        session.clearLonLat();
        //Toast.makeText(getApplicationContext(),"main onDestroy" , Toast.LENGTH_SHORT).show();
        Intent intent = new Intent();
        setResult(0 , intent);
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Closing Activity")
                .setMessage("Are you sure you want to close this activity?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }

                })
                .setNegativeButton("No", null)
                .show();
    }
}
