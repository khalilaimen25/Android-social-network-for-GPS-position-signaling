package ti.dam.geoloc_memoire;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;

public class SettingActivity extends AppCompatActivity {

    //Button delete;
    LinearLayout delete , language , about;

    RadioButton engish , french , arabic;
    TextView lang_ok;

    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

//    static String delete_url = "http://169.254.30.200:2145/Projects/Android/app/delete_account.php";
//    static String check_psw = "169.254.30.200:2145/Projects/Android/app/check_psw.php";

    static String delete_url = "http://android-php.000webhostapp.com/android/delete_account.php";
    static String check_psw = "http://android-php.000webhostapp.com/android/check_psw.php";

    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        setupActionBar();

        //delete = (Button) findViewById(R.id.setting_delete_tv);
        delete = (LinearLayout) findViewById(R.id.setting_delete_tv);
        language = (LinearLayout) findViewById(R.id.setting_language_tv);
        about = (LinearLayout) findViewById(R.id.setting_about_tv);


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText input = new EditText(SettingActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                input.setLayoutParams(lp);

                AlertDialog.Builder builder = new AlertDialog.Builder(SettingActivity.this);
                builder.setTitle(getResources().getText(R.string.delete_ac_txt1));
                builder.setMessage(getResources().getText(R.string.delete_ac_txt2));
                builder.setView(input);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

                Button b = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String psw = input.getText().toString();
                        Session session = new Session(getApplication());
                        if (psw.length() != 0)
                            ////psw verification method
//                        if (passwd_verification(check_psw , session.getID() , psw)) {
                            if (psw.equals(session.getPasswd())) {

                        delete_account(delete_url , session.getID());
                        Intent intent = new Intent();
                        setResult(9999 ,intent);
                        finish();}
                        else
                            input.setError("password inccorect");
                        else
                            input.setError("password required");

                    }
                });
            }
        });

        language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                final Dialog D = new Dialog(SettingActivity.this);
                D.requestWindowFeature(Window.FEATURE_NO_TITLE); //disable dialog title bar
                D.setContentView(R.layout.custom_radio_view);
                //D.setTitle(getResources().getText(R.string.choose_language));
                D.setCancelable(true);
                D.show();

                engish = (RadioButton) D.findViewById(R.id.english);
                french = (RadioButton) D.findViewById(R.id.french);
                arabic = (RadioButton) D.findViewById(R.id.arabic);
                lang_ok = (TextView) D.findViewById(R.id.lang_ok);

                Session session = new Session(getApplication());
                String l = session.getLang();

                if (l.equals("fr")) french.setChecked(true);
                if (l.equals("en")) engish.setChecked(true);
                if (l.equals("ar")) arabic.setChecked(true);

                lang_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (engish.isChecked()){
                           setLocale("en");
                        }
                        if (french.isChecked()){
                            setLocale("fr");
                        }
                        if (arabic.isChecked()) {
                            setLocale("ar");
                        }
                        D.dismiss();
                    }
                });



            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



            }
        });

    }


    public void setLocale(String lang){
        Session session = new Session(getApplicationContext());
        session.setLang(lang);

        Locale locale = new Locale(lang);
        Resources resources = getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        resources.updateConfiguration(configuration,displayMetrics);
        Intent intent = new Intent(getBaseContext(),luncherActivity.class);
        startActivity(intent);
        //finish();
    }

    static boolean ok;
    private boolean passwd_verification(String url , final String id , final String psw) {

        requestQueue2 = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(getApplicationContext() , ""+response , Toast.LENGTH_SHORT).show();
                        if (response.contains("success"))
                            ok = true;

                        else
                            ok = false;


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "erreur de connexion\nverifier votre internet", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);


            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id" , id);
                params.put("psw" , psw);
                return params;
            }
        };
        requestQueue2.add(stringRequest);

        return ok;
    }

    public void delete_account(String url ,final String id ){

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Session session = new Session(getApplicationContext());
                            session.clearSession();
                        }else
                            Toast.makeText(getApplicationContext() , "profile non supprimer\nesseiyer encore" ,Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "erreur de connexion \nverifier votre internet", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);


            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id" , id);
                return params;
            }
        };
        requestQueue.add(stringRequest);

    }
}
