package ti.dam.geoloc_memoire;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;

import java.util.Locale;

import ti.dam.geoloc_memoire.Object_class.Session;

public class luncherActivity extends AppCompatActivity {

    com.android.volley.RequestQueue requestQueue;

    static String login_url = "http://android-php.000webhostapp.com/android/login.php";
//    static String login_url = "http://169.254.30.200:2145/Projects/Android/app/login.php";

    static String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_luncher);


        Session session = new Session(getApplication());
        id = session.getID();

        if(isOnline()){
            //Toast.makeText(getApplicationContext(),"internet on",Toast.LENGTH_SHORT).show();




        Log.i("TAG" , "===========================***=========="+session.getEmail()+" "+session.getPasswd());

        if (id.equals("")){

            Intent intent = new Intent(getApplicationContext() , LoginActivity.class);
            startActivityForResult(intent,100);
        }
        else{

            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivityForResult(i,101);
        }

        }else{
            //Toast.makeText(getApplicationContext(),"internet off",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext() , LoginActivity.class);
            startActivityForResult(intent,100);}

        Locale locale = new Locale(session.getLang());
        Resources resources = getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        resources.updateConfiguration(configuration,displayMetrics);


//            requestQueue = Volley.newRequestQueue(getApplication());
//
//            StringRequest stringRequest = new StringRequest(Request.Method.POST, login_url,
//                    new Response.Listener<String>() {
//                        @Override
//                        public void onResponse(String response) {
//
//                            if (response.contains("success")) {
//                                Intent i = new Intent(getApplicationContext(), MainActivity.class);
//                                startActivity(i);
//                            }
//
//                            if (response.contains("failed")) {
//                                Intent intent = new Intent(getApplicationContext() , LoginActivity.class);
//                                startActivity(intent);
//                            }
//
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
//
//                }
//            }) {
//                @Override
//                protected Map<String, String> getParams() throws AuthFailureError {
//                    Map<String, String> params = new HashMap<>();
//                    params.put("login_email" , session.getEmail());
//                    params.put("login_passwd" , session.getPasswd());
//                    return params;
//                }
//            };
//            requestQueue.add(stringRequest);

        }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }



    //    @Override
//    protected void onResume() {
//        super.onResume();
//        Toast.makeText(getApplication(),"launcher onResume",Toast.LENGTH_SHORT).show();
//        if (id.equals("")) {
//            Intent intent = new Intent(getApplication(), LoginActivity.class);
//            startActivityForResult(intent, 100);
//        }else{
//            Intent intent = new Intent(getApplication(), MainActivity.class);
//            startActivityForResult(intent, 101);
//        }
//
//    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == 0){
                finish();
        }
        if (requestCode == 101 && resultCode == 0){
                finish();
        }

    }

public boolean isOnline() {
    ConnectivityManager cm =
        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkInfo netInfo = cm.getActiveNetworkInfo();
    return netInfo != null && netInfo.isConnectedOrConnecting();
}
}
