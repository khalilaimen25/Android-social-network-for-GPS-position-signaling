package ti.dam.geoloc_memoire;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;

public class profileFriendActivity extends AppCompatActivity {

    static String id,position;
    TextView name,email,date,location,tel;
    ImageView photo;
    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;


    ProgressDialog progressDialog;

//    static String profile_ami_url = "http://169.254.30.200:2145/Projects/Android/app/profile_ami.php";
//    static String delete_ami_url = "http://169.254.30.200:2145/Projects/Android/app/delete_friend.php";

    static String profile_ami_url = "http://android-php.000webhostapp.com/android/profile_ami.php";
    static String delete_ami_url = "http://android-php.000webhostapp.com/android/delete_friend.php";



    Button delete , call;

    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_friend);
        setupActionBar();

        name = (TextView) findViewById(R.id.profile_ami_name);
        date = (TextView) findViewById(R.id.profile_ami_birthdate);
        email = (TextView) findViewById(R.id.profile_ami_email);
        delete = (Button) findViewById(R.id.delete_ami);
        call = (Button) findViewById(R.id.call_ami);
        location = (TextView) findViewById(R.id.profile_ami_loc);
        photo = (ImageView) findViewById(R.id.profile_ami_photo_p);
        tel = (TextView) findViewById(R.id.profile_ami_tel);

        Intent i = getIntent();
        Bundle bundle = i.getExtras();

        id = bundle.getString("id_account");
        position = bundle.getString("position");
//        id = i.getStringExtra("id_account");
//        position = i.getStringExtra("position");
        Log.i("tag" , "id=== : "+id);

        
        profileAmi(profile_ami_url,id);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Session session = new Session(getApplicationContext());



                final EditText input = new EditText(profileFriendActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                input.setLayoutParams(lp);

                AlertDialog.Builder builder = new AlertDialog.Builder(profileFriendActivity.this);
                builder.setTitle(getResources().getText(R.string.delete_ac_txt1));
                builder.setMessage(getResources().getText(R.string.delete_ac_txt2));
                builder.setView(input);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

                Button b = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String psw = input.getText().toString();
                        Session session = new Session(getApplication());
                        if (psw.length() != 0)
                            ////psw verification method
//                        if (passwd_verification(check_psw , session.getID() , psw)) {
                            if (psw.equals(session.getPasswd())) {

                                deleteAmi(delete_ami_url , session.getID() ,id);
                                Intent intent = new Intent();
                                Log.i("tag" , "position 3=== : "+position);
                                intent.putExtra("position" , position);
                                setResult(RESULT_OK , intent);
                                finish();
                            }
                            else
                                input.setError(getResources().getString(R.string.incorrect_email));
                        else
                            input.setError(getResources().getString(R.string.incorrect_password));

                    }
                });


//                deleteAmi(delete_ami_url , id_ac ,id);
//                Intent intent = new Intent();
//                Log.i("tag" , "position 3=== : "+position);
//                intent.putExtra("position" , position);
//                setResult(RESULT_OK , intent);
//                finish();

            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View view) {

                String numTel = tel.getText().toString();

                if (!numTel.equals("null")){
                    Intent call = new Intent(Intent.ACTION_CALL);
                    call.setData(Uri.parse("tel:" +numTel ));
                    if (ActivityCompat.checkSelfPermission(getApplication(), Manifest.permission
                            .CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    startActivity(call);
                }else{
                    Toast.makeText(getApplication(),""+getResources().getString(R.string.tel_not_available),Toast.LENGTH_SHORT).show();
                    call.setBackground(getResources().getDrawable(R.drawable.custom_button_deny));
                    call.setClickable(false);
                }


            }
        });


    }

    public void profileAmi(String url , final String id)
    {

        progressDialog = new ProgressDialog(profileFriendActivity.this);
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getApplication());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray infos = response.getJSONArray("infos");
                            for (int i=0 ; i < infos.length() ; i++){
                                JSONObject info = infos.getJSONObject(i);



                                String Ufirstname = info.getString("firstname");
                                String Ulastname = info.getString("lastname");
                                String Uemail = info.getString("email");
                                String Udate = info.getString("birthdate");
                                String Uposition = info.getString("position");
                                String Uphoto = info.getString("image_path");
                                String Utel = info.getString("telephone");

//                                String url = "http://169.254.30.200:2145/Projects/Android/app/"+Uphoto;
                                String url = "http://android-php.000webhostapp.com/android/"+Uphoto;
                                Picasso.with(getApplicationContext()).load(url).into(photo);

                                name.setText(Ufirstname+" "+Ulastname);
                                ActionBar actionBar = getSupportActionBar();
                                actionBar.setTitle(Ufirstname+" "+Ulastname+" Profile");
                                email.setText(Uemail);
                                date.setText(Udate);
                                if (!Utel.equals("null"))
                                    tel.setText(Utel);
                                else
                                    tel.setText(getResources().getString(R.string.map_not_available));

                                if (!Uposition.equals("null"))
                                location.setText(Uposition);
                                else
                                location.setText(getResources().getString(R.string.map_not_available));


                            }



                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        progressDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext() , "Error connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id" , id);
                //params.put("id_account" , id_account);
                return params;

            }
        };

        requestQueue.add(jsonObjectRequest);

    }

    private void deleteAmi(String url , final String id_ac , final String id_ami){

        requestQueue2 = Volley.newRequestQueue(getApplication());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")) {
                            Toast.makeText(getApplicationContext(), "amis supprimer", Toast.LENGTH_SHORT).show();


                        }

                        if (response.contains("failed")) {
                            Toast.makeText(getApplicationContext(), "ami non suprimer", Toast.LENGTH_SHORT).show();

                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
               // Toast.makeText(getApplicationContext(), "failed", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idac" , id_ac);
                params.put("idami" , id_ami);
                return params;
            }
        };
        requestQueue2.add(stringRequest);
    }


}
