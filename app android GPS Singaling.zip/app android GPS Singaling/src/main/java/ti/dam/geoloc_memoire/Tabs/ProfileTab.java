package ti.dam.geoloc_memoire.Tabs;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.GPS_Service;
import ti.dam.geoloc_memoire.HistoricActivity;
import ti.dam.geoloc_memoire.LoginActivity;
import ti.dam.geoloc_memoire.MapsActivity;
import ti.dam.geoloc_memoire.ModifierActivity;
import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.RegisterActivity;
import ti.dam.geoloc_memoire.SettingActivity;

import static android.app.Activity.RESULT_OK;


/**
 * Created by khalilrockmetal on 03/03/17.
 */

public class ProfileTab extends Fragment {

    TextView fullname, Pemail, nmbr_demande, date, position,etat , tel;
    Switch aSwitch , offline_online;
    static String res;
    ImageButton modif_pic;
    com.github.clans.fab.FloatingActionMenu setting;
    //Button map ;
    com.github.clans.fab.FloatingActionButton map,fab_setting,fab_modify,fab_logout , fab_hist;
    ImageView etat_conex , profile_offline_online , profile_image;

    BroadcastReceiver broadcastReceiver;


    static String encoded_string = null, image_name = null ;
    static Bitmap bitmap = null;
    static File file;
    static Uri file_uri;

    @Override
    public void onResume() {
        super.onResume();
        if(broadcastReceiver == null){
            broadcastReceiver =new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {


                    position = (TextView) getActivity().findViewById(R.id.position);
                    Session session = new Session(getContext());
                    String id = session.getID();

                    String lon = ""+intent.getExtras().get("lon");
                    String lat = ""+intent.getExtras().get("lat");

                    Toast.makeText(getContext(),""+intent.getExtras().get("cord"),Toast.LENGTH_SHORT).show();
//                    Log.i("//","-********************** "+""+intent.getExtras().get("cord"));
                    String pos = ""+intent.getExtras().get("cord");
                    position.setText(pos);


                    setLocationON(set_positionON , ""+intent.getExtras().get("cord") ,lat, lon, id);

                    SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy  HH:mm");
                    String time = date.format(new Date());

                    setHistorique(hist_pos , id , lat , lon , ""+intent.getExtras().get("cord"),time);

                    session.setLoc(pos);
                    session.setLon(lon);
                    session.setLat(lat);



                }
            };
        }
       getContext().registerReceiver(broadcastReceiver,new IntentFilter("location_update"));
    }

    @Override
    public  void onPause() {
        super.onPause();
        if (broadcastReceiver != null) {
            getContext().unregisterReceiver(broadcastReceiver);
            broadcastReceiver = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(broadcastReceiver != null){
            getContext().unregisterReceiver(broadcastReceiver);
            Session session = new Session(getContext());
            setLocationOFF(set_positionOFF,session.getID());

        }
    }


    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;
    com.android.volley.RequestQueue requestQueue3;
    com.android.volley.RequestQueue requestQueue4;
    com.android.volley.RequestQueue requestQueue5;
    com.android.volley.RequestQueue requestQueue6;
//
//    static String profile_url = "http://169.254.30.200:2145/Projects/Android/app/profile.php";
//    static String logout = "http://169.254.30.200:2145/Projects/Android/app/logout.php";
//    static String nmbr_demande_url = "http://169.254.30.200:2145/Projects/Android/app/nmbr_demande.php";

    static String profile_url = "http://android-php.000webhostapp.com/android/profile.php";
    static String nmbr_demande_url = "http://android-php.000webhostapp.com/android/nmbr_demande.php";
    static String logout = "http://android-php.000webhostapp.com/android/logout.php";
    static String set_positionON = "http://android-php.000webhostapp.com/android/set_position.php";
    static String set_positionOFF = "http://android-php.000webhostapp.com/android/set_positionOFF.php";
    static String hist_pos = "http://android-php.000webhostapp.com/android/hist_pos.php";
    static String modify_img = "http://android-php.000webhostapp.com/android/modify_img.php";





    ProgressDialog progressDialog;


    static String id_account;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.tab_profile, container, false);
        setHasOptionsMenu(true);

        fullname = (TextView) rootView.findViewById(R.id.profile_name);
        Pemail = (TextView) rootView.findViewById(R.id.profile_email);
        offline_online = (Switch) rootView.findViewById(R.id.switch_offline_online);
        offline_online.setChecked(true);
        etat = (TextView) rootView.findViewById(R.id.offile_online);
        aSwitch = (Switch) rootView.findViewById(R.id.switch1);
        nmbr_demande = (TextView) rootView.findViewById(R.id.nmbr_demande);
        date = (TextView) rootView.findViewById(R.id.profile_birth_date);
        position = (TextView) rootView.findViewById(R.id.position);
        tel = (TextView) rootView.findViewById(R.id.profile_telephone);
        modif_pic = (ImageButton) rootView.findViewById(R.id.profile_pic_upload);

        etat_conex = (ImageView) rootView.findViewById(R.id.etat_conexion);
        map = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.profile_map);
        fab_setting = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.fab_setting);
        fab_logout = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.fab_logout);
        fab_modify = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.fab_modify);
        fab_hist = (com.github.clans.fab.FloatingActionButton) rootView.findViewById(R.id.profile_hist);

        profile_offline_online = (ImageView) rootView.findViewById(R.id.profile_offline_online);
        profile_image = (ImageView) rootView.findViewById(R.id.profile_image);


        final Session session = new Session(getContext());
        String email = session.getEmail();
        String passwd = session.getPasswd();
        getProfile(profile_url, email, passwd);

        id_account = session.getID();
        //nmbr_demande.setText(getNumDemandes(nmbr_demande_url , id_account));


        requestQueue2 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, nmbr_demande_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.isEmpty())
                            nmbr_demande.setText("0");
                        else
                            nmbr_demande.setText(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext(), "Error connection", Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id", id_account);

                return params;
            }
        };

        requestQueue2.add(stringRequest2);



        fab_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(getContext() , SettingActivity.class);
                startActivityForResult(intent1 , 1111);
            }
        });
        fab_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                offline(logout,id_account);
                session.clearSession();
                Intent i = new Intent(getContext(),LoginActivity.class);
                startActivity(i);
                getActivity().finish();
            }
        });
        fab_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), ModifierActivity.class);
                startActivityForResult(intent,123);
            }
        });
        fab_hist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(),HistoricActivity.class);
                startActivity(i);
            }
        });
//        setting.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                PopupMenu popupMenu = new PopupMenu(getContext(), view);
//                popupMenu.getMenuInflater().inflate(R.menu.menu_main, popupMenu.getMenu());
//
//                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                    @Override
//                    public boolean onMenuItemClick(android.view.MenuItem menuItem) {
//
//                        switch (menuItem.getItemId()) {
//                            case R.id.settings:
//
//                                return true;
//                            case R.id.deconnexion:
//
//                                return true;
//                            case R.id.modifier_profile:
//
//
//                            default:
//                                return true;
//
//                        }
//                    }
//                });
//                popupMenu.show();
//            }
//        });

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("tag","*****************************"+session.getLat());
                if (session.getLat().equals("") && session.getLon().equals("")){
                    //Toast.makeText(getContext(),getResources().getText(R.string.set_gps_on),Toast.LENGTH_SHORT).show();
                    Snackbar.make(getView(),getResources().getText(R.string.set_gps_on),Snackbar.LENGTH_SHORT).show();
                }else {
                    Intent intent = new Intent(getContext(), MapsActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("x", session.getLat());
                    bundle.putString("y", session.getLon());
                    bundle.putString("pos", session.getLoc());
                    bundle.putString("name", session.getName());
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });

        offline_online.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isCheked) {
                if (!isCheked){
                    offline(logout , session.getID());
                    etat_conex.setBackground(getResources().getDrawable(R.drawable.offline));
                    profile_offline_online.setBackground(getResources().getDrawable(R.drawable.offline_e));
                    etat.setText(getResources().getText(R.string.your_offline));
                }else {
                    online(logout , session.getID());
                    etat_conex.setBackground(getResources().getDrawable(R.drawable.online));
                    profile_offline_online.setBackground(getResources().getDrawable(R.drawable.online_e));
                    etat.setText(getResources().getText(R.string.your_online));
                }
            }
        });

        modif_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickImage();
            }
        });


        if (!runTime_Permession()) //////// check PERMESSION for GPS android Version
            enable_switch();



        return rootView;
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 123)
            if (resultCode == 321){
                String email = data.getStringExtra("email");
                String passwd = data.getStringExtra("passwd");
                getProfile(profile_url,email,passwd);
            }

        if (requestCode == 1111)
            if (resultCode == 9999){
                getActivity().finish();
            }

        if (requestCode == 1 && resultCode == RESULT_OK) {
            final Bundle extras = data.getExtras();
            if (extras != null) {
                //Get image
                bitmap = extras.getParcelable("data");
                profile_image.setImageBitmap(bitmap);
                Session s = new Session(getContext());
                modify_img(modify_img , image_name, encoded_string,  s.getID());
            }
        }
    }

    private void modify_img(String modify_img, final String img_n ,final String img_code,final String id) {
        if (bitmap == null) {
        }else {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);

            byte[] array = stream.toByteArray();
            encoded_string = Base64.encodeToString(array, 0);


            Log.i("tag", " ***** " + image_name);
        }

        getFileUri();

        requestQueue6 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, modify_img,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //Log.i("tag", "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" + response);
                        Toast.makeText(getContext(), "success", Toast.LENGTH_SHORT).show();

                        if (response.contains("success")) {
                            profile_image.setImageBitmap(bitmap);

                            //new Encode_image().execute();

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "failed connection ", Toast.LENGTH_SHORT).show();
//                               Log.i("tag", "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" + error);
//
//                               Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("encoded_string", img_code);
                params.put("image_name", img_n);
                params.put("id",id);

                return params;
            }
        };
        requestQueue6.add(stringRequest);
    }

    private void enable_switch() {

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isCheked) {

                if (isCheked) {
                    Toast.makeText(getContext(), "ON", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getContext() , GPS_Service.class);
                    getContext().startService(i);

                } else {
                    Toast.makeText(getContext(), "OFF", Toast.LENGTH_SHORT).show();
                    position.setText(getResources().getText(R.string.not_in_service));
                    Session session = new Session(getContext());
                    setLocationOFF(set_positionOFF,session.getID());
                    session.clearLonLat();
                    Intent i = new Intent(getContext() , GPS_Service.class);
                    getContext().stopService(i);
                }

            }
        });

    }


    private boolean runTime_Permession() {

        if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(getContext() , Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(getContext() , Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){

            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION , Manifest.permission.ACCESS_COARSE_LOCATION} , 100);
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode , permissions , grantResults);
        if (requestCode == 100){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED){

            }else {

            }
        }

    }

    

    public void getProfile(String url , final String email , final String passwd){

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.i("TAG" , ""+response);
                        try {
                            JSONArray infos = response.getJSONArray("infos");
                            for (int i=0 ; i < infos.length() ; i++){
                                JSONObject info = infos.getJSONObject(i);


                                String id = info.getString("id_account");

                                Session session = new Session(getContext());
                                session.setID(id);

                                String Ufirstname = info.getString("firstname");
                                String Ulastname = info.getString("lastname");
                                String Uemail = info.getString("email");
                                String Udate = info.getString("birthdate");
                                String etat = info.getString("etat");
                                String pos = info.getString("position");
                                String img = info.getString("image_path");
                                String telephone = info.getString("telephone");

                                if (!img.equals("")){
//                                String url = "http://169.254.30.200:2145/Projects/Android/app/"+img;
                                    String url = "http://android-php.000webhostapp.com/android/"+img;
                                Picasso.with(getContext()).load(url).into(profile_image);}
                                else
                                    profile_image.setBackground(getResources().getDrawable(R.drawable.user));

                                fullname.setText(Ufirstname+" "+Ulastname);
                                Pemail.setText(Uemail);
                                date.setText(Udate);
                                if (etat.equals("c")){
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                                        etat_conex.setBackground(getResources().getDrawable(R.drawable.online));
                                    }
                                }
                                if (!pos.equals("null"))
                                    position.setText(pos);
                                else
                                    position.setText("non disponible");

                                if (!telephone.equals("null"))
                                    tel.setText(telephone);
                                else
                                    tel.setText(getResources().getString(R.string.map_not_available));




                                session.setName(Ufirstname+" "+Ulastname);

                            }



                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext() , "Error connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();


                params.put("email" , email);
                params.put("passwd" , passwd);
                //params.put("id_account" , id_account);
                return params;

            }
        };



        requestQueue.add(jsonObjectRequest);
    }

    private void online(String url, final String id) {
        requestQueue3 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "error connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idaccount" , id);
                params.put("etat","online");
                return params;
            }
        };
        requestQueue3.add(stringRequest);
    }
    private void offline(String url , final String id_account) {
        requestQueue3 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getContext(), "erreur", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("idaccount" , id_account);
                params.put("etat","offline");
                return params;
            }
        };
        requestQueue3.add(stringRequest);
    }


    public String getNumDemandes(String url , final String id){

        requestQueue2 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        res = response;

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext()  ,"Error connection" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id", id);

                return params;
            }
        };

        requestQueue2.add(stringRequest);

        return res;

    }

    public void setLocationON(String url , final String position , final String x , final String y , final String id){

        requestQueue4 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {



                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "failed connection", Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("position" , position);
                params.put("x",x);
                params.put("y",y);
                params.put("id" , id);
                return params;
            }
        };
        requestQueue4.add(stringRequest);

    }

    public void setLocationOFF(String url ,final String id){

        requestQueue4 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "failed connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id" , id);
                return params;
            }
        };
        requestQueue4.add(stringRequest);

    }

    public void setHistorique(String url  , final String id , final String x , final String y , final String position , final String date){

        requestQueue5 = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getContext(), ""+response, Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "failed connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("position" , position);
                params.put("x",x);
                params.put("y",y);
                params.put("date",date);
                params.put("id" , id);
                return params;
            }
        };
        requestQueue5.add(stringRequest);

    }

    //////////////////PICK IMAGE FROM GALLERY///////////////////
    public void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("scale", true);
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("return-data", true);
        //intent.putExtra(MediaStore.EXTRA_OUTPUT , file_uri);
        startActivityForResult(intent, 1);
    }

    private void getFileUri() {
        Session s = new Session(getContext());
        image_name = "img_"+s.getEmail().hashCode()+""+s.getPasswd().hashCode()+".jpg";
        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                + File.separator + image_name);
        file_uri = Uri.fromFile(file);
    }





}
