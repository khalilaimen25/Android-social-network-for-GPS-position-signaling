package ti.dam.geoloc_memoire.Object_class;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by khalilrockmetal on 20/03/17.
 */

public class User implements Parcelable{

    public String id;
    public String firstname;
    public String lastname;
    public String etat;
    public String position;
    public String  x;
    public String y;
    public String img;


    public User(String id , String firstname , String lastname , String img , String etat){
        this.id = id ;
        this.firstname = firstname;
        this.lastname = lastname ;
        this.img = img;
        this.etat = etat;
    }

    public User(String id , String firstname , String lastname,String position ,String etat,String img){
        this.id = id ;
        this.firstname = firstname;
        this.lastname = lastname ;
        this.etat = etat;
        this.position = position;
        this.img = img;

    }

    public User(String id , String firstname , String lastname, String img , String position,String x , String y ,String etat){
        this.id = id ;
        this.firstname = firstname;
        this.lastname = lastname ;
        this.etat = etat;
        this.position = position;
        this.x = x;
        this.y = y;
        this.img = img;

    }

    protected User(Parcel in) {
        id = in.readString();
        firstname = in.readString();
        lastname = in.readString();
        etat = in.readString();
        position = in.readString();
        x = in.readString();
        y = in.readString();
        img = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getId(){
        return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(firstname);
        parcel.writeString(lastname);
        parcel.writeString(etat);
        parcel.writeString(position);
        parcel.writeString(x);
        parcel.writeString(y);
        parcel.writeString(img);
    }
}
