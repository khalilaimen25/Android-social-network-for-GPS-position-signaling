package ti.dam.geoloc_memoire.Tabs;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Adapters.CustomDemandeAdapter;
import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;
import ti.dam.geoloc_memoire.userProfileActivity;

/**
 * Created by khalilrockmetal on 03/03/17.
 */

public class DemandeTab extends Fragment {

    ListView list_demande ;

    public ArrayList<User> demandes ;

    CustomDemandeAdapter customDemandeAdapter;

    com.android.volley.RequestQueue requestQueue;

    Button accept , deny ;


    ProgressDialog progressDialog;
//
//    static String url = "http://169.254.30.200:2145/Projects/Android/app/gerer_demande.php";

    static String url = "http://android-php.000webhostapp.com/android/gerer_demande.php";



    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tab_demande, container, false);

        demandes = new ArrayList<>();

        list_demande = (ListView) rootView.findViewById(R.id.list_demande);
        list_demande.setDivider(this.getResources().getDrawable(R.drawable.transperent_color));
        list_demande.setDividerHeight(3);


        customDemandeAdapter = new CustomDemandeAdapter(getContext() , demandes);
        customDemandeAdapter.clear();

//        progressDialog = new ProgressDialog(getActivity());
//        progressDialog.setMessage("Plzz Wait...");
//        progressDialog.setIndeterminate(false);
//        progressDialog.setCancelable(true);
//        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
//        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getContext());


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray users = response.getJSONArray("demandes");
                            for (int i=0 ; i < users.length() ; i++){

                                JSONObject user = users.getJSONObject(i);

                                String id = user.getString("id_account");
                                String firstname = user.getString("firstname");
                                String lastname = user.getString("lastname");
                                String img = user.getString("image_path");

                                User new_demande = new User(id , firstname , lastname , img ,null);
                                demandes.add(new_demande);

                                Log.i("tag" , "demande "+i +" = "+firstname);
                                Log.i("tag" , "size = "+demandes.size());
                            }

                            list_demande.setAdapter(customDemandeAdapter);


                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        //progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext() , "Error connection" , Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                //progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                Session session = new Session(getContext());
                String id_account = session.getID();
                params.put("idaccount" , id_account);
                //params.put("id_account" , id_account);
                return params;

            }
        };

        requestQueue.add(jsonObjectRequest);

//        demandes.add(new User("12" , "zzz" , "vvv"));
        list_demande.setAdapter(customDemandeAdapter);



        list_demande.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final String id_user = demandes.get(i).id;
                Intent intent = new Intent(getContext() , userProfileActivity.class);
                intent.putExtra("id" , id_user);
                startActivity(intent);

            }
        });


        return rootView;
    }


}
