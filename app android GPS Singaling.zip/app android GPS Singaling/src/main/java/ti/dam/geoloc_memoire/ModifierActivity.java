package ti.dam.geoloc_memoire;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;

public class ModifierActivity extends AppCompatActivity {


    EditText fname , lname , email , passwd  ,date , tel ;
    Button modifier;
    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

//    static String get_info_url = "http://169.254.30.200:2145/Projects/Android/app/profile_ami.php";
//    static String modifier_url = "http://169.254.30.200:2145/Projects/Android/app/modifier_account.php";
//    static String check_psw = "http://169.254.30.200:2145/Projects/Android/app/check_psw.php";

    static String get_info_url = "http://android-php.000webhostapp.com/android/profile_ami.php";
    static String modifier_url = "http://android-php.000webhostapp.com/android/modifier_account.php";
    static String check_psw = "http://android-php.000webhostapp.com/android/check_psw.php";


    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier);
        setupActionBar();

        fname = (EditText) findViewById(R.id.fname_mod);
        lname = (EditText) findViewById(R.id.lname_mod);
        email = (EditText) findViewById(R.id.email_mod);
        passwd = (EditText) findViewById(R.id.passwd_mod);
        date = (EditText) findViewById(R.id.date_mod);
        tel = (EditText) findViewById(R.id.tel_mod);
        modifier = (Button) findViewById(R.id.modifier_valid);

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,get_info_url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray infos = response.getJSONArray("infos");
                            for (int i=0 ; i < infos.length() ; i++){
                                JSONObject info = infos.getJSONObject(i);

                                String Ufirstname = info.getString("firstname");
                                String Ulastname = info.getString("lastname");
                                String Uemail = info.getString("email");
                                String Udate = info.getString("birthdate");
                                Session session = new Session(getApplicationContext());
                                String Upassword = session.getPasswd();
                                String Utel = info.getString("telephone");

                                fname.setText(Ufirstname);
                                lname.setText(Ulastname);
                                email.setText(Uemail);
                                date.setText(Udate);
                                passwd.setText(Upassword);
                                if (Utel.equals("null"))
                                    tel.setText(getResources().getText(R.string.map_not_available));
                                else
                                    tel.setText(Utel);

                            }




                        }catch (JSONException e){
                            e.printStackTrace();
                        }



                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                //Toast.makeText(getApplicationContext() , "Error", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);


            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                Session session = new Session(getApplication());
                params.put("id" , session.getID());

                return params;

            }
        };

        requestQueue.add(jsonObjectRequest);




        modifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText input = new EditText(ModifierActivity.this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT);
                input.setLayoutParams(lp);

                AlertDialog.Builder builder = new AlertDialog.Builder(ModifierActivity.this);
                builder.setTitle(getResources().getText(R.string.modify_ac_txt1));
                builder.setMessage(getResources().getText(R.string.modify_ac_txt2));
                builder.setView(input);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

                Button b = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String psw = input.getText().toString();
                        Session session = new Session(getApplication());
                        if (psw.length() != 0){
                            ////psw verification method
//                            if (passwd_verification(check_psw , session.getID() , psw)) {
                            if (psw.equals(session.getPasswd())) {

                                String fn = fname.getText().toString();
                                String ln = lname.getText().toString();
                                String em = email.getText().toString();
                                String pswd = passwd.getText().toString();
                                String dt = date.getText().toString();
                                String ttel = tel.getText().toString();

                                modifier(modifier_url,fn,ln,em,pswd,dt , ttel);

                                }
                            else{
                                input.setError("password inccorect");}
                       }else{
                            input.setError("password required");}

                    }
                });

//                String fn = fname.getText().toString();
//                String ln = lname.getText().toString();
//                String em = email.getText().toString();
//                String psw = passwd.getText().toString();
//                String dt = date.getText().toString();
//
//                modifier(modifier_url,fn,ln,em,psw,dt);
            }
        });


    }


    /////////////////////////////CHECK PASSWORD //////////////////////
    static boolean ok;
    private boolean passwd_verification(String url , final String id , final String psw) {

        requestQueue2 = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //Toast.makeText(getApplicationContext() , ""+response , Toast.LENGTH_SHORT).show();
                        if (response.contains("success"))
                            ok = true;

                        else
                            ok = false;


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id" , id);
                params.put("psw" , psw);
                return params;
            }
        };
        requestQueue2.add(stringRequest);

        return ok;
    }
    ///////////////////////////////////////////////GET PROFILE INFO /////////////////////////////////////
    public void modifier(String url ,final String fn ,final String ln ,final String em ,final String psw ,final String dt  ,final String tt){


        requestQueue2 = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Toast.makeText(getApplicationContext() , "profile modifier" ,Toast.LENGTH_SHORT).show();
                            Session session = new Session(getApplicationContext());
                            session.setEmail(em);
                            session.setPasswd(psw);
                            Intent intent = new Intent();
                            intent.putExtra("email" ,session.getEmail() );
                            intent.putExtra("passwd" ,session.getPasswd() );
                            setResult(321,intent);
                            finish();
                        }else
                            Toast.makeText(getApplicationContext() , "profile non modifier\nesseiyer encore" ,Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "erreur de connexion \nverifier votre internet", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);


            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("fname" , fn);
                params.put("lname" , ln);
                params.put("email" , em);
                params.put("passwd" , psw);
                params.put("date" , dt);
                params.put("tel",tt);
                Session session = new Session(getApplicationContext());
                params.put("id" ,session.getID() );
                return params;
            }
        };
        requestQueue2.add(stringRequest);


    }
}
