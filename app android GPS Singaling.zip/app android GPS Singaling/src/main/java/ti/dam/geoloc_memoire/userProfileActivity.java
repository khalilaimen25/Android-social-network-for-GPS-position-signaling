package ti.dam.geoloc_memoire;

import android.app.ProgressDialog;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;

public class userProfileActivity extends AppCompatActivity {

    Button add;
    TextView name , tel , email , date ;
    static boolean exist ;
    ImageView photo;

    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

    ProgressDialog progressDialog;

//    static String profile_user_url = "http://169.254.30.200:2145/Projects/Android/app/profile_ami.php";
//    static String url_demande = "http://169.254.30.200:2145/Projects/Android/app/envoyer_demande.php";

    static String profile_user_url = "http://android-php.000webhostapp.com/android/profile_ami.php";
    static String url_demande = "http://android-php.000webhostapp.com/android/envoyer_demande.php";



    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_user);
        setupActionBar();

        add = (Button) findViewById(R.id.add_profile_ami);
        name = (TextView) findViewById(R.id.profile_user_name);
        //email = (TextView) findViewById(R.id.profile_user_email);
        date = (TextView) findViewById(R.id.profile_user_birthdate);
        photo = (ImageView) findViewById(R.id.profile_user_photo);

        final String id_recep = getIntent().getStringExtra("id");

        profileUser(profile_user_url , id_recep);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Session session= new Session(getApplicationContext());
                String id_emet = session.getID();

                if (!profileAddUser(url_demande , id_emet , id_recep )){
                    Toast.makeText(getApplicationContext()  ,getResources().getString(R.string.send_invitation_exist) ,Toast.LENGTH_SHORT).show();
                    add.setBackgroundColor(getResources().getColor(R.color.added));

                }

            }
        });


    }

    public void profileUser(String url , final String id_ac){

        progressDialog = new ProgressDialog(userProfileActivity.this);
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(false);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue = Volley.newRequestQueue(getApplication());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray infos = response.getJSONArray("infos");
                            for (int i=0 ; i < infos.length() ; i++){
                                JSONObject info = infos.getJSONObject(i);



                                String Ufirstname = info.getString("firstname");
                                String Ulastname = info.getString("lastname");
                                //String Uemail = info.getString("email");
                                String Udate = info.getString("birthdate");
                                String Uphoto = info.getString("image_path");

//                                String url = "http://169.254.30.200:2145/Projects/Android/app/"+Uphoto;
                                String url = "http://android-php.000webhostapp.com/android/"+Uphoto;
                                Picasso.with(getApplicationContext()).load(url).into(photo);

                                name.setText(Ufirstname+" "+Ulastname);
                                ActionBar actionBar = getSupportActionBar();
                                actionBar.setTitle(Ufirstname+" "+Ulastname+" Profile");
                                //email.setText(Uemail);
                                date.setText(Udate);


                            }



                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                        progressDialog.dismiss();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext() , "Error connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("id" , id_ac);
                //params.put("id_account" , id_account);
                return params;

            }
        };

        requestQueue.add(jsonObjectRequest);

    }


    public boolean profileAddUser(String url  , final String id_emet , final String id_recep ) {



        requestQueue2 = Volley.newRequestQueue(getApplication());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response.contains("success")){
                            Toast.makeText(getApplicationContext()  ,getResources().getString(R.string.send_invitation) ,Toast.LENGTH_SHORT).show();
                            exist = true;
                        }
                        if (response.contains("failed")){
                            Toast.makeText(getApplicationContext()  ,getResources().getString(R.string.send_invitation_error) ,Toast.LENGTH_SHORT).show();
                        }
                        if (response.contains("exist")){
                            exist = false;
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext()  ,"ERORR" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("idemet", id_emet);
                params.put("idrecep", id_recep);

                return params;
            }
        };
        requestQueue2.add(stringRequest);

        return exist;
    }

    }
