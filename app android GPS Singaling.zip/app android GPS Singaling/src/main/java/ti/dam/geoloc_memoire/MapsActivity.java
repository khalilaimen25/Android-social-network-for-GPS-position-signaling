package ti.dam.geoloc_memoire;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    static String lat;
    static String lon;
    static String pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

         //Add a marker in Sydney and move the camera
        Session session = new Session(getApplicationContext());

//        Double lon = Double.valueOf(session.getLon());
//        Double lat = Double.valueOf(session.getLat());

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

         lat = bundle.getString("x");
         lon = bundle.getString("y");
         pos = bundle.getString("pos");

        if (lat != null) {
            Log.i("tag", "**********************" + lat + " " + lon);
            Double x = Double.parseDouble(lat);
            Double y = Double.parseDouble(lon);

            LatLng sydney = new LatLng(x, y);

            CameraUpdate zoom=CameraUpdateFactory.zoomTo(10);

            mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(x, y)).title("" +bundle.getString("name") ))
                    .showInfoWindow();
//            mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in " + pos));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
            mMap.animateCamera(zoom);
        }

        try {

            ArrayList<User> amis = intent.getParcelableArrayListExtra("amis");
            Toast.makeText(getApplicationContext(), ""+amis.size(), Toast.LENGTH_SHORT).show();


                for (int i = 0; i < amis.size(); i++) {

                    Double xx = Double.parseDouble(amis.get(i).x);
                    Double yy = Double.parseDouble(amis.get(i).y);

                    CameraUpdate zoom=CameraUpdateFactory.zoomTo(10);

                    mMap.addMarker(new MarkerOptions()
                            .position(new LatLng(xx, yy)).title("" + amis.get(i).firstname + " " + amis.get(i).lastname))
                            .showInfoWindow();

                    //mMap.addMarker(new MarkerOptions().position(new LatLng(xx, yy)).title("Marker in " + amis.get(i).firstname + " " + amis.get(i).firstname));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(xx, yy)));
                    mMap.animateCamera(zoom);


                }


        }catch (Exception e){

        }
    }

//    BroadcastReceiver broadcastReceiver;
//    static double lon;
//    static double lan;
//    static String location;
//    @Override
//    public void onResume() {
//        super.onResume();
//        if(broadcastReceiver == null){
//            broadcastReceiver =new BroadcastReceiver() {
//                @Override
//                public void onReceive(Context context, Intent intent) {
//
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//
////                            Toast.makeText(getContext(),""+intent.getExtras().get("cord"),Toast.LENGTH_SHORT).show();
//                    lon = Double.parseDouble(""+intent.getExtras().get("lon"));
//                    lan = Double.parseDouble(""+intent.getExtras().get("lan"));
//                    location = ""+intent.getExtras().get("cord");
//
//                }
//            };
//        }
//        getApplicationContext().registerReceiver(broadcastReceiver,new IntentFilter("location_update"));
//    }
}
