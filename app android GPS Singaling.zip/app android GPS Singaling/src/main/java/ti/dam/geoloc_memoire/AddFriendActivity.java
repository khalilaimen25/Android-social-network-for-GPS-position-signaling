package ti.dam.geoloc_memoire;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Intent;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.SearchView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Adapters.CustomUsersAdapter;
import ti.dam.geoloc_memoire.Object_class.Session;
import ti.dam.geoloc_memoire.Object_class.User;


public class AddFriendActivity extends AppCompatActivity {

    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

//    static String users_url = "http://169.254.30.200:2145/Projects/Android/app/users.php";

    static String users_url = "http://android-php.000webhostapp.com/android/users.php";


    ProgressDialog progressDialog;

    ArrayList<User> users_list = new ArrayList<>();
    CustomUsersAdapter user_adapter;
    ListView Ulist;
//    SearchView searchView;
    Button add;
    ImageView photo;

    Session session ;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.search, menu);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.search));
        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint(getResources().getString(R.string.Search));


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //user_adapter.getFilter().filter(newText);
                user_adapter = new CustomUsersAdapter(getApplicationContext() , users_list);
                    user_adapter.clear();

                session = new Session(getApplication());
                getUsers(users_url , session.getID() ,newText);
                return false;
            }
        });

        return true;
    }

private void setupActionBar() {
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null) {
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);
        setupActionBar();

//        ActionBar actionBar = getSupportActionBar();
////        assert actionBar != null;
////        actionBar.setDisplayHomeAsUpEnabled(true);
////        actionBar.setHomeButtonEnabled(true);
//        actionBar.setCustomView(R.layout.search_view);
//        final View search = (View) actionBar.getCustomView().findViewById(R.id.saerch_friends);
//        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);


//        users_list = new ArrayList<>();

        Ulist = (ListView) findViewById(R.id.users_list);
        Ulist.setDivider(this.getResources().getDrawable(R.drawable.transperent_color));
        Ulist.setDividerHeight(3);
        //searchView = (SearchView) findViewById(R.id.saerch_friends);
        photo = (ImageView) findViewById(R.id.user_photo);



        //user_adapter = new CustomUsersAdapter(getApplicationContext() , users_list);


        //Session session = new Session(getApplication());
//        final String id_account = session.getID();
//        Log.i("aaa" , "id = :"+id_account);



//        ImageView imageView = (ImageView) findViewById(R.id.back);
//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                finish();
//            }
//        });



       // getUsers(users_url , id_account);



        //Ulist.setAdapter(user_adapter);



        Ulist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                final String id_user = users_list.get(i).id;
                Intent intent = new Intent(getApplicationContext() , userProfileActivity.class);
                intent.putExtra("id" , id_user);
                startActivity(intent);

            }
        });

    }


    public void getUsers(String url , final  String id_account ,final String s){

//        progressDialog = new ProgressDialog(AddFriendActivity.this);
//        progressDialog.setMessage("Plzz Wait...");
//        progressDialog.setIndeterminate(false);
//        progressDialog.setCancelable(false);
//        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
//        progressDialog.show();

        //user_adapter = new CustomUsersAdapter(getApplicationContext() , users_list);

        requestQueue = Volley.newRequestQueue(getApplicationContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {



                    @Override
                    public void onResponse(JSONObject response) {



                        try {
                            JSONArray users = response.getJSONArray("users");
                            for (int i=0 ; i < users.length() ; i++){
                                JSONObject user = users.getJSONObject(i);

                                String id = user.getString("id_account");
                                String firstname = user.getString("firstname");
                                String lastname = user.getString("lastname");
                                String img = user.getString("image_path");

                                User new_user = new User(id , firstname , lastname , img , "user");
                                users_list.add(new_user);

                            }


                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        try {
                            JSONArray users = response.getJSONArray("demande");
                            for (int i=0 ; i < users.length() ; i++){
                                JSONObject user = users.getJSONObject(i);

                                String id = user.getString("id_account");
                                String firstname = user.getString("firstname");
                                String lastname = user.getString("lastname");
                                String img = user.getString("image_path");

                                User new_user = new User(id , firstname , lastname , img ,"demande");
                                users_list.add(new_user);
                                //Toast.makeText(getApplication(),""+firstname+""+lastname,Toast.LENGTH_SHORT).show();

                            }


                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        Ulist.setAdapter(user_adapter);
                        user_adapter.notifyDataSetChanged();
                        Log.i("tag" , "list ============== "+users_list.size());
                        //progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


               // Toast.makeText(getApplicationContext() , "ErrorUser" , Toast.LENGTH_SHORT).show();
                Log.i("tag" , "==============================="+error);
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                //progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();


                params.put("id" , id_account);
                params.put("string" , s);
                //params.put("id_account" , id_account);
                return params;

            }
        };



        requestQueue.add(jsonObjectRequest);
    }
}
