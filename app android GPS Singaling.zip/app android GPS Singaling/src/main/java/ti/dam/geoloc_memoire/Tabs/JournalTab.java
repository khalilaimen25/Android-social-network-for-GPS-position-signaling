package ti.dam.geoloc_memoire.Tabs;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Adapters.CustomJournaPostAdapter;
import ti.dam.geoloc_memoire.Object_class.Post;
import ti.dam.geoloc_memoire.R;
import ti.dam.geoloc_memoire.Object_class.Session;

import static android.app.Activity.RESULT_OK;

/**
 * Created by khalilrockmetal on 03/03/17.
 */

public class JournalTab extends Fragment {

    ListView list_of_posts ;
    static  ArrayList<Post> posts ;
    CustomJournaPostAdapter customJournaPostAdapter;

    ImageView journal_photo;
    EditText post;
    Button publier , pick_image ;
    TextView image_title ;

    ImageView post_image_p,post_img_t;
    File file;
    Uri file_uri;
    Bitmap bitmap;
    String image_name = "",encoded_string = "";


//    static String publier_url = "http://169.254.30.200:2145/Projects/Android/app/publier_post.php";
//    static String get_posts_url = "http://169.254.30.200:2145/Projects/Android/app/get_posts.php";
//    static String get_profile_url = "http://169.254.30.200:2145/Projects/Android/app/profile.php";

    static String publier_url = "http://android-php.000webhostapp.com/android/publier_post.php";
    static String get_posts_url = "http://android-php.000webhostapp.com/android/get_posts.php";
      static String get_profile_url = "http://android-php.000webhostapp.com/android/profile.php";

    ProgressDialog progressDialog;

    com.android.volley.RequestQueue requestQueue2;
    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue request;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             final Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.tab_journal, container, false);

        post = (EditText) rootView.findViewById(R.id.post_write);
        publier = (Button) rootView.findViewById(R.id.post_publier);
        pick_image = (Button) rootView.findViewById(R.id.post_pick_image);
        post_img_t = (ImageView) rootView.findViewById(R.id.post_image_title);
        post_image_p = (ImageView) rootView.findViewById(R.id.post_image_p);
        journal_photo = (ImageView) rootView.findViewById(R.id.post_img);



        posts = new ArrayList<>();


        journal_profile_pic(get_profile_url);

        list_of_posts = (ListView) rootView.findViewById(R.id.list_posts);

        customJournaPostAdapter = new CustomJournaPostAdapter(getContext() , posts);

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Plzz Wait...");
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(true);
        progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        requestQueue2 = Volley.newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,get_posts_url,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray posts_list = response.getJSONArray("posts");


                            for (int i=0 ; i < posts_list.length() ; i++){
                                JSONObject post = posts_list.getJSONObject(i);

                                String fname = post.getString("firstname");
                                String lname = post.getString("lastname");
                                String text = post.getString("text");
                                String date = post.getString("date");
                                String position = post.getString("Pposition");
                                String img = post.getString("Pimage_path");
                                String imp_p = post.getString("image_path");

                                posts.add(0, new Post(imp_p , img , fname+" "+lname , text , date , position));
                            }

                            list_of_posts.setAdapter(customJournaPostAdapter);

                            Log.i("tag" , "************* sisze *** "+posts.size());
                            //customJournaPostAdapter.notifyDataSetChanged();



                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                        progressDialog.dismiss();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext() , "Error get posts", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                progressDialog.dismiss();

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                Session session = new Session(getContext());
                params.put("idaccount" ,session.getID());
                return params;

            }
        };

        requestQueue2.add(jsonObjectRequest);

        list_of_posts.setAdapter(customJournaPostAdapter);


        publier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (bitmap == null) {

                }else {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);

                    byte[] array = stream.toByteArray();
                    encoded_string = Base64.encodeToString(array, 0);
                }



                String text = post.getText().toString();
                if (!text.isEmpty()){

                    Session session = new Session(getContext());
                    String name = session.getName();

                    SimpleDateFormat date = new SimpleDateFormat("HH:mm  dd-MM-yyyy");
                    String time = date.format(new Date());
                    //posts.add(0 , new Post("" ,name, text, time, session.getLoc()));
                    //img.setImageBitmap(bitmap);

                    publierPost(publier_url , text ,time , session.getLoc() , image_name , encoded_string);
                    post_img_t.setImageBitmap(null);
                    bitmap = null ;image_name="";encoded_string="";


                }
                else
                    post.setError("champ est vide");

//                setUserVisibleHint(true);
                post.setText("");
                customJournaPostAdapter.notifyDataSetChanged();

            }
        });

        pick_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickimage();
            }
        });



        return rootView;
    }

    private void pickimage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        getFileUri();
        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("scale", true);
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("return-data", true);
        //intent.putExtra(MediaStore.EXTRA_OUTPUT , file_uri);
        startActivityForResult(intent, 1);
    }

    private void getFileUri() {
        Session session = new Session(getContext());

        SimpleDateFormat date = new SimpleDateFormat("HH:mm  dd-MM-yyyy");
        String time = date.format(new Date());

        image_name = "img_p_"+session.getID().hashCode()+""+time.hashCode()+".jpg";
        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                + File.separator + image_name);
        file_uri = Uri.fromFile(file);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            final Bundle extras = data.getExtras();
            if (extras != null) {
                //Get image
                bitmap = extras.getParcelable("data");
                post_img_t.setImageBitmap(bitmap);
                Log.i("tag","************ img title .. "+image_name);

            }


        }
    }

    BroadcastReceiver broadcastReceiver;

//    @Override
//    public void onResume() {
//        super.onResume();
//        if(broadcastReceiver == null){
//            broadcastReceiver =new BroadcastReceiver() {
//                @Override
//                public void onReceive(Context context, Intent intent) {
//
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////                    Toast.makeText(getContext(),""+intent.getExtras().get("cord"),Toast.LENGTH_SHORT).show();
//                    pos = ""+intent.getExtras().get("cord");
//
//
//                }
//            };
//        }
//        getContext().registerReceiver(broadcastReceiver,new IntentFilter("location_update"));
//    }


    public void publierPost(String url  , final String text , final String date , final String pos , final String img_name , final String img_encode){

        requestQueue = Volley.newRequestQueue(getContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.contains("success")){
                         Toast.makeText(getContext() , "publier reussie" , Toast.LENGTH_SHORT).show();
                            setUserVisibleHint(true);
                        }else
                            Log.i("tag" , "erooooooor"+response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext()  ,"ERORR" ,Toast.LENGTH_SHORT).show();
                //Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                Session session = new Session(getContext());

                params.put("id_account" , session.getID());
                params.put("post_text" , text);
                params.put("post_date" , date);
                params.put("post_pos" , pos);
                params.put("encoded_string" , img_encode);
                params.put("image_name" , img_name);
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        requestQueue.add(stringRequest);

    }
    public void journal_profile_pic(String url){

       

        request = Volley.newRequestQueue(getContext());

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,url,
                new Response.Listener<JSONObject>() {

                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onResponse(JSONObject response) {


                        try {
                            JSONArray infos_list = response.getJSONArray("infos");



                                JSONObject info = infos_list.getJSONObject(0);

                                String img = info.getString("image_path");
//                                String url = "http://169.254.30.200:2145/Projects/Android/app/"+img;
                            String url = "http://android-php.000webhostapp.com/android/"+img;


                            if (img.equals("")){
                                journal_photo.setBackground(getContext().getResources().getDrawable(R.drawable.profilew));
                            }else {
                                Picasso.with(getContext()).load(url).into(journal_photo);
                            }
                            list_of_posts.setAdapter(customJournaPostAdapter);

                            Log.i("tag" , "************* sisze *** "+posts.size());
                            //customJournaPostAdapter.notifyDataSetChanged();


                        }catch (JSONException e){
                            e.printStackTrace();

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getContext() , "Error connection", Toast.LENGTH_SHORT).show();
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                Session session = new Session(getContext());
                params.put("email" ,session.getEmail());
                params.put("passwd" ,session.getPasswd());
                return params;

            }
        };

        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        request.add(jsonObjectRequest);

    }

    @Override
    public void setUserVisibleHint(boolean isFragmentVisible_) {
        super.setUserVisibleHint(true);


        if (this.isVisible()) {
            // we check that the fragment is becoming visible
            if (isFragmentVisible_) {

               // Toast.makeText(getContext() , "fragment selected" , Toast.LENGTH_SHORT).show();

                posts = new ArrayList<>();


                list_of_posts = (ListView) getActivity().findViewById(R.id.list_posts);

                customJournaPostAdapter = new CustomJournaPostAdapter(getContext() , posts);


                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Plzz Wait...");
                progressDialog.setIndeterminate(false);
                progressDialog.setCancelable(true);
                progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
                progressDialog.show();

                requestQueue2 = Volley.newRequestQueue(getContext());

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,get_posts_url,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {

                                progressDialog.dismiss();

                                try {
                                    JSONArray posts_list = response.getJSONArray("posts");


                                    for (int i=0 ; i < posts_list.length() ; i++){
                                        JSONObject post = posts_list.getJSONObject(i);

                                        String fname = post.getString("firstname");
                                        String lname = post.getString("lastname");
                                        String text = post.getString("text");
                                        String date = post.getString("date");
                                        String position = post.getString("Pposition");
                                        String img = post.getString("Pimage_path");
                                        String img_profile = post.getString("image_path");

                                        posts.add(0, new Post(img_profile , img , fname+" "+lname , text , date ,position));
                                    }

                                    list_of_posts.setAdapter(customJournaPostAdapter);
                                    customJournaPostAdapter.notifyDataSetChanged();



                                }catch (JSONException e){
                                    e.printStackTrace();
                                }



                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getContext() , "Error connection", Toast.LENGTH_SHORT).show();
                        Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
                        progressDialog.dismiss();

                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();

                        Session session = new Session(getContext());
                        params.put("idaccount" ,session.getID());
                        return params;

                    }
                };


                requestQueue2.add(jsonObjectRequest);

                //list_of_posts.setAdapter(customJournaPostAdapter);


            }
        }
    }

//    @Override
//    public void onResume() {
//        super.onResume();
//        Toast.makeText(getContext() , "onRes" , Toast.LENGTH_SHORT).show();
//
//       posts.clear();
//
//        customJournaPostAdapter = new CustomJournaPostAdapter(getContext() , posts);
//
//        requestQueue = Volley.newRequestQueue(getContext());
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST ,get_posts_url,
//                new Response.Listener<JSONObject>() {
//
//                    @Override
//                    public void onResponse(JSONObject response) {
//
//
//                        try {
//                            JSONArray posts_list = response.getJSONArray("posts");
//
//
//                            for (int i=0 ; i < posts_list.length() ; i++){
//                                JSONObject post = posts_list.getJSONObject(i);
//
//                                String name = post.getString("name");
//                                String text = post.getString("text");
//                                String date = post.getString("date");
//
//                                posts.add(0, new Post(R.drawable.photo1 , name , text , date , "constantine , Algeria"));
//                            }
//
//                            list_of_posts.setAdapter(customJournaPostAdapter);
//                            customJournaPostAdapter.notifyDataSetChanged();
//
//                        }catch (JSONException e){
//                            e.printStackTrace();
//                        }
//
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(getContext() , "Error", Toast.LENGTH_SHORT).show();
//                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);
//
//            }
//        }){
//            @Override
//            public Map<String, String> getHeaders() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//
//                Session session = new Session(getContext());
//                params.put("idaccount" ,session.getID());
//                return params;
//
//            }
//        };
//
//        requestQueue.add(jsonObjectRequest);
//
//        customJournaPostAdapter.notifyDataSetChanged();
//    }
}
