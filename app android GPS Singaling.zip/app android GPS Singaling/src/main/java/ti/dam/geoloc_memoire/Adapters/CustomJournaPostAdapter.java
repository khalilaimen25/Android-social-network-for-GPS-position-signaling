package ti.dam.geoloc_memoire.Adapters;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import ti.dam.geoloc_memoire.Object_class.Post;
import ti.dam.geoloc_memoire.R;

/**
 * Created by khalilrockmetal on 01/03/17.
 */

public class CustomJournaPostAdapter extends BaseAdapter {

    Context context;
    ArrayList<Post> posts;

    public CustomJournaPostAdapter(Context context , ArrayList<Post> posts){
        this.context=context;
        this.posts=posts;
    }

    @Override
    public int getCount() {
        return posts.size();
    }

    @Override
    public Object getItem(int position){
        return posts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return posts.indexOf(getItem(position));
    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null){
            view = layoutInflater.inflate(R.layout.custom_post , null);
        }

        ImageView photo = (ImageView) view.findViewById(R.id.post_img);
        ImageView post_img = (ImageView) view.findViewById(R.id.post_image_p);
        TextView name = (TextView) view.findViewById(R.id.post_name);
        TextView text = (TextView) view.findViewById(R.id.post_text);
        TextView date = (TextView) view.findViewById(R.id.post_date);
        TextView location = (TextView) view.findViewById(R.id.post_location);


        if (!posts.get(position).image_p.equals("")) {
//            String url = "http://169.254.30.200:2145/Projects/Android/app/" + posts.get(position).image_p;
            String url = "http://android-php.000webhostapp.com/android/" + posts.get(position).image_p;
            photo.setMaxWidth(80);
            photo.setMaxHeight(60);
            Picasso.with(context).load(url).into(photo);
        }else
            photo.setBackground(context.getResources().getDrawable(R.drawable.profilew));


        if (!posts.get(position).image.equals("")) {
//            String url = "http://169.254.30.200:2145/Projects/Android/app/" + posts.get(position).image;
            String url = "http://android-php.000webhostapp.com/android/" + posts.get(position).image;
            photo.setMaxWidth(80);
            photo.setMaxHeight(60);
            Picasso.with(context).load(url).into(post_img);
        }
        name.setText(posts.get(position).name);
        text.setText(posts.get(position).post_text);
        date.setText(posts.get(position).date);
        if (!posts.get(position).location.equals("null"))
        location.setText(posts.get(position).location);
        else
            location.setText("");




        return view;
    }

    public void clear(){

        this.posts.clear();
    }
}
