package ti.dam.geoloc_memoire;

import android.app.DatePickerDialog;
import android.app.DialogFragment;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ti.dam.geoloc_memoire.Object_class.Session;

public class RegisterActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    EditText firstname,lastname,email,passwd,passwd_conf,date ,tel;
    Button register;
    LinearLayout photo_reg;
    ImageView photo;

    static String encoded_string = null, image_name = null ;
    static Bitmap bitmap = null;
    static File file;
    static Uri file_uri;

    static  String e=null , p=null;

    int  hashEmail,hashPasswd;

    ProgressDialog progressDialog;
    com.android.volley.RequestQueue requestQueue;
    com.android.volley.RequestQueue requestQueue2;

    static String new_account_url = "http://android-php.000webhostapp.com/android/new_account.php";

//    static String new_account_url = "http://169.254.30.200:2145/Projects/Android/app/new_account.php";


    private void setupActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        setupActionBar();

        firstname = (EditText) findViewById(R.id.fname_reg);
        lastname = (EditText) findViewById(R.id.lname_reg);
        email = (EditText) findViewById(R.id.email_reg);
        passwd = (EditText) findViewById(R.id.passwd_reg);
        passwd_conf = (EditText) findViewById(R.id.passwd_c_reg);
        photo_reg = (LinearLayout) findViewById(R.id.photo_reg);
        register = (Button) findViewById(R.id.register_reg);
        date = (EditText) findViewById(R.id.date_reg);
        photo = (ImageView) findViewById(R.id.image_test);
        tel = (EditText) findViewById(R.id.tel_reg);


        photo_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickImage();
            }
        });


        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePicker(view);
            }
        });



        requestQueue = Volley.newRequestQueue(RegisterActivity.this);



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String fn = firstname.getText().toString();
                final String ln = lastname.getText().toString();
                 e = email.getText().toString();
                 p = passwd.getText().toString();
                final String pc = passwd_conf.getText().toString();
                final String d = date.getText().toString();
                final String  t = tel.getText().toString();


                if (bitmap == null) {
                }else {
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);

                    byte[] array = stream.toByteArray();
                    encoded_string = Base64.encodeToString(array, 0);


                    Log.i("tag", " ***** " + image_name);
                }

               if(!isEmpty(fn , ln , e , p , pc , d)) {

                   if (isValid(e , p , d)) {

                       if (p.equals(pc)){


                       progressDialog = new ProgressDialog(RegisterActivity.this);
                       progressDialog.setMessage("Plzz Wait...");
                       progressDialog.setIndeterminate(false);
                       progressDialog.setCancelable(false);
                       progressDialog.setProgress(ProgressDialog.STYLE_HORIZONTAL);
                       progressDialog.show();


                       hashEmail = e.hashCode();
                       hashPasswd = p.hashCode();

                       getFileUri();

                       StringRequest stringRequest = new StringRequest(Request.Method.POST, new_account_url,
                               new Response.Listener<String>() {
                                   @Override
                                   public void onResponse(String response) {

                                       //Log.i("tag", "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" + response);

                                       if (response.contains("success")) {
                                           Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();

                                           //new Encode_image().execute();

                                           Session session = new Session(getApplicationContext());
                                           session.setEmail(e);
                                           Intent intent = new Intent();
                                           intent.putExtra("email", e);
                                           intent.putExtra("passwd", p);
                                           setResult(RESULT_OK, intent);
                                           finish();


                                       }

                                       if (response.contains("exist")) {
                                           email.setError("email exist deja essey un autre svp");
                                       }

                                       progressDialog.dismiss();

                                   }
                               }, new Response.ErrorListener() {
                           @Override
                           public void onErrorResponse(VolleyError error) {
                               Toast.makeText(getApplicationContext(), "failed connection ", Toast.LENGTH_SHORT).show();
                               progressDialog.dismiss();
//                               Log.i("tag", "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr" + error);
//
//                               Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, error);

                           }
                       }) {
                           @Override
                           protected Map<String, String> getParams() throws AuthFailureError {
                               Map<String, String> params = new HashMap<>();
                               params.put("reg_firstname", fn);
                               params.put("reg_lastname", ln);
                               params.put("reg_email", e);
                               params.put("reg_passwd", p);
                               params.put("reg_date", d);
                               params.put("reg_tel" , t);
                               params.put("encoded_string", encoded_string);
                               params.put("image_name", image_name);


                               return params;
                           }
                       };
                       requestQueue.add(stringRequest);

                    }else {
                           passwd_conf.setError("incorrect password");
                       }

                   }

               }

            }
        }); ///////////// END  REGISTER.ONCLICK





    } ////////// END ONCREATE




//////////////////PICK IMAGE FROM GALLERY///////////////////
    public void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);

        intent.setType("image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("scale", true);
        intent.putExtra("outputX", 256);
        intent.putExtra("outputY", 256);
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("return-data", true);
        //intent.putExtra(MediaStore.EXTRA_OUTPUT , file_uri);
        startActivityForResult(intent, 1);
    }

    private void getFileUri() {
        image_name = "img_"+hashEmail+""+hashPasswd+".jpg";
        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                + File.separator + image_name);
        file_uri = Uri.fromFile(file);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            final Bundle extras = data.getExtras();
            if (extras != null) {
                //Get image
                bitmap = extras.getParcelable("data");
                photo.setImageBitmap(bitmap);


            }


        }
    }




    /////////////// EMAIL & PASSWORD VALID ? ///////////////////
    public boolean isValid(String em , String ps ,String bd){

        boolean b = true;

        if (! em.contains("@") || em.contains(" ")){
            email.setError("invalid email");
            b = false;
        }
        if (ps.length() < 5){
            passwd.setError("password to short");
            b = false;
        }

        if (bd.length() < 10){
            date.setError("date invalid");
            b = false;
        }

        return b;
    }

    //////////////FIELDS ARE REQUIRED /////////////////////////
    public boolean isEmpty(String fn , String ln , String em , String ps,String psc , String bd){

        boolean b = false;

        if (fn.length() == 0)
        {firstname.setError("field is required"); b = true;}

        if (ln.length() == 0)
        {lastname.setError("field is required"); b = true;}

        if (em.length() == 0)
        {email.setError("field is required"); b = true;}

        if (ps.length() == 0 || ps.contains(" "))
        {passwd.setError("field is required"); b = true;}

        if (psc.length() == 0 || ps.contains(" "))
        {passwd.setError("field is required"); b = true;}

        if (bd.length() == 0 )
        {date.setError("field is required"); b = true;}

        return b;

    }

    public void datePicker(View view){
        DatePickerFragment fragment = new DatePickerFragment();
        fragment.show(getFragmentManager() , "date");
    }

    private void setDate(final Calendar calendar){
        final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG);
        date.setText(dateFormat.format(calendar.getTime()));
    }


    @Override
    public void onDateSet(DatePicker view, int year, int mounth, int day) {
        Calendar calendar = new GregorianCalendar(year,mounth,day);
        setDate(calendar);
    }
    public static class DatePickerFragment extends DialogFragment{

        @Override
        public Dialog onCreateDialog(Bundle saveInstanceState){
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            return new DatePickerDialog(getActivity(),
                    (DatePickerDialog.OnDateSetListener)getActivity() , year , month ,day);
        }
    }
}
