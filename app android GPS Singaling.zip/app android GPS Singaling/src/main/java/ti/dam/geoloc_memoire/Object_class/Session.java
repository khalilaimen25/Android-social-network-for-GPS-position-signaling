package ti.dam.geoloc_memoire.Object_class;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by khalilrockmetal on 20/03/17.
 */

public class Session {

    private SharedPreferences preferences;

    public Session(Context context){

        preferences = PreferenceManager.getDefaultSharedPreferences(context);

    }

    //////////////// ID ACCOUNT //////////////
    public void setID(String id){
        preferences.edit().putString("id_account" , id).apply();
    }

    public String getID(){
        String id = preferences.getString("id_account","");
        return id;
    }

    //////////////////EMAIL ACCOUNT /////////////
    public void setEmail(String email){
        preferences.edit().putString("email" , email).apply();
    }

    public String getEmail(){
        String email = preferences.getString("email","");
        return email;
    }

    ////////////////PASSWORD ACCOUNT ////////////////
    public void setPasswd(String passwd){
        preferences.edit().putString("passwd",passwd).apply();
    }

    public String getPasswd(){
        String passwd = preferences.getString("passwd" , "");
        return passwd;
    }

    ///////////////ACCOUNT NAME //////////////////////////

    public void setName(String name){
       preferences.edit().putString("name" , name).apply();
    }
    public String getName(){
        String name = preferences.getString("name","");
        return name;
    }

    //////////////// Acocunt POSITION ////////////////////////

    public void setLoc(String pos){
        preferences.edit().putString("position" , pos).apply();
    }
    public String getLoc(){
        String pos = preferences.getString("position","");
        return pos;
    }

    ////////
    public void setLon(String x){
        preferences.edit().putString("lon" , x).apply();
    }
    public String getLon(){
        String lon = preferences.getString("lon", "");
        return lon;
    }
    //////////////////
    public void setLat(String y){
        preferences.edit().putString("lat" , y).apply();
    }
    public String getLat(){
        String lat = preferences.getString("lat", "");
        return lat;
    }

    public void clearLonLat(){
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("lon");
        editor.remove("lat");
        editor.remove("position");
        editor.apply();
    }

    ////////////////////LANGUAGE////////////////////////////

    public void setLang(String lang){
        preferences.edit().putString("lang" , lang).apply();
    }
    public String getLang(){
        return preferences.getString("lang", "");
    }
    ///////////////////////////////////////////////////////////////////////////////

    public void clearSession(){
      SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.commit();

    }
}
