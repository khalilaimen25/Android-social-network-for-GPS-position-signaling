package ti.dam.geoloc_memoire.Object_class;

/**
 * Created by khalilrockmetal on 01/03/17.
 */

public class Post {

    public String image_p;
    public String image;
    public String name;
    public String post_text;
    public String date;
    public String location;

    public Post(String image_p , String image , String name , String post_text , String date, String  location)
    {
        this.image_p = image_p;
        this.image = image;
        this.name = name;
        this.post_text = post_text;
        this.date = date;
        this.location = location;
    }
}
